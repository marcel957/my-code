<?php
session_start();

if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

include("koneksi.php");
$result_join = $mysqli->query("SELECT
pj.PenjualanID,
pl.PelangganID,
pj.TanggalPenjualan,
pr.ProdukID,
dp.JumlahProduk,
dp.Subtotal
FROM penjualan AS pj
INNER JOIN pelanggan AS pl 
    ON pj.PelangganID = pl.PelangganID
INNER JOIN detailpenjualan AS dp 
    ON pj.PenjualanID = dp.PenjualanID
INNER JOIN produk AS pr 
    ON dp.ProdukID = pr.ProdukID;")
?>
<?php
// Mendapatkan data produk untuk ditampilkan di tabel
$result = $mysqli->query("SELECT `ProdukID`, `NamaProduk`, `Harga`, `Stok` FROM `produk` ORDER BY `ProdukID`");
if (!$result) {
    die("Error: " . $mysqli->error);
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplikasi Kasir</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: #f9f9f9; font-family: Arial, sans-serif; padding: 12px; }
        .container { max-width: 900px; margin: 0 auto; }
        .header { background: #2c3e50; color: white; padding: 15px; margin-bottom: 12px; border-radius: 4px; display: flex; justify-content: space-between; align-items: center; }
        .header h1 { font-size: 24px; margin-bottom: 5px; }
        .header p { font-size: 12px; opacity: 0.9; }
        .nav-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; margin-bottom: 20px; }
        .nav-card { background: white; border: 1px solid #ddd; padding: 15px; text-align: center; cursor: pointer; transition: all 0.3s; }
        .nav-card:hover { background: #f0f0f0; border-color: #999; transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        .nav-card a { text-decoration: none; color: #333; display: block; }
        .nav-icon { font-size: 32px; margin-bottom: 8px; }
        .nav-title { font-weight: bold; font-size: 14px; margin-bottom: 4px; }
        .nav-desc { font-size: 11px; color: #666; }
        .section { background: white; border: 1px solid #ddd; padding: 15px; margin-bottom: 12px; }
        .section h2 { font-size: 16px; color: #333; margin-bottom: 12px; border-bottom: 2px solid #2c3e50; padding-bottom: 8px; }
        .section ul { list-style: none; }
        .section li { margin-bottom: 8px; }
        .section a { color: #2196F3; text-decoration: none; font-size: 13px; display: inline-block; padding: 6px 0; }
        .section a:hover { text-decoration: underline; color: #0b7dda; }
        .stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px; margin-bottom: 20px; }
        .stat-box { background: white; border: 1px solid #ddd; padding: 15px; text-align: center; }
        .stat-number { font-size: 24px; font-weight: bold; color: #2c3e50; margin-bottom: 5px; }
        .stat-label { font-size: 12px; color: #666; }
        .footer { text-align: center; font-size: 11px; color: #999; padding-top: 20px; border-top: 1px solid #ddd; margin-top: 20px; }
        .action-btn { display: inline-block; padding: 8px 16px; background: #4CAF50; color: white; text-decoration: none; border: none; border-radius: 3px; cursor: pointer; font-size: 12px; margin-right: 8px; }
        .action-btn:hover { background: #45a049; }
        .action-btn.secondary { background: #2196F3; }
        .action-btn.secondary:hover { background: #0b7dda; }
        .btn-logout { display: inline-block; padding: 6px 14px; background: rgba(255,255,255,0.15); color: white; text-decoration: none; border: 1px solid rgba(255,255,255,0.3); border-radius: 3px; font-size: 12px; transition: background 0.3s; }
        .btn-logout:hover { background: rgba(255,255,255,0.25); }
        
        /* Table Styles */
        table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 13px; }
        th, td { padding: 12px; border: 1px solid #ddd; text-align: left; }
        th { background-color: #f8f9fa; font-weight: bold; color: #2c3e50; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        tr:hover { background-color: #f1f1f1; }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div>
                <h1>💳 Aplikasi Kasir Toko</h1>
                <p>Sistem manajemen transaksi penjualan dan inventory</p>
            </div>
            <a href="login.php?logout" class="btn-logout">Logout</a>
        </div>

        <!-- Navigation Cards -->
        <div class="nav-grid">
            <div class="nav-card">
                <a href="data/penjualan.php">
                    <div class="nav-icon">🛒</div>
                    <div class="nav-title">Penjualan</div>
                    <div class="nav-desc">Buat & kelola transaksi penjualan</div>
                </a>
            </div>
            <div class="nav-card">
                <a href="data/produk.php">
                    <div class="nav-icon">📦</div>
                    <div class="nav-title">Produk</div>
                    <div class="nav-desc">Manajemen data produk & stok</div>
                </a>
            </div>
            <div class="nav-card">
                <a href="data/pelanggan.php">
                    <div class="nav-icon">👥</div>
                    <div class="nav-title">Pelanggan</div>
                    <div class="nav-desc">Kelola data pelanggan</div>
                </a>
            </div>
            <div class="nav-card">
                <a href="data/detailpenjualan.php">
                    <div class="nav-icon">📋</div>
                    <div class="nav-title">Detail Penjualan</div>
                    <div class="nav-desc">Lihat detail transaksi</div>
                </a>
            </div>
            <div class="nav-card">
                <a href="cetakpdf.php">
                    <div class="nav-icon">📑</div>
                    <div class="nav-title">Cetak</div>
                    <div class="nav-desc">Lihat Cetak</div>
                </a>
            </div>
        </div>
        <!-- Laporan Inner Join Section -->
        <div class="section">
            <h2>📊 Laporan Transaksi Lengkap (Inner Join)</h2>
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>ID Penjualan</th>
                            <th>ID Pelanggan</th>
                            <th>Tanggal Penjualan</th>
                            <th>ID Produk</th>
                            <th>Jumlah</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if ($result_join && $result_join->num_rows > 0) {
                            while($row = $result_join->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>#" .htmlspecialchars($row['PenjualanID']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['PelangganID']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['TanggalPenjualan']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['ProdukID']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['JumlahProduk']) . "</td>";
                                echo "<td>Rp " . number_format($row['Subtotal'], 0, ',', '.') . "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='6' style='text-align:center; padding: 20px;'>Tidak ada data transaksi ditemukan</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- Footer -->
        <div class="footer">
            <p>© 2026 Aplikasi Kasir | Semua data tersimpan aman di database</p>
        </div>
    </div>
</body>
</html>
