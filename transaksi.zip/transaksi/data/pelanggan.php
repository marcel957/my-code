<?php
include("../koneksi.php");

// API Endpoint untuk mendapatkan data dalam format JSON
if (isset($_GET['action']) && $_GET['action'] == 'get') {
    header('Content-Type: application/json');
    $result = $mysqli->query("SELECT `PelangganID`, `NamaPelanggan`, `Alamat`, `NomorTelepon` FROM `pelanggan` ORDER BY `PelangganID`");
    
    if (!$result) {
        echo json_encode([]);
        exit;
    }
    
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    
    echo json_encode($data);
    exit;
}

// Tambah data
if (isset($_POST['submit']) && $_POST['submit'] == 'Tambah') {
    $PelangganID = trim($_POST['PelangganID'] ?? '');
    $NamaPelanggan = trim($_POST['NamaPelanggan'] ?? '');
    $Alamat = trim($_POST['Alamat'] ?? '');
    $NomorTelepon = trim($_POST['NomorTelepon'] ?? '');

    // Validasi input
    if (empty($PelangganID) || empty($NamaPelanggan) || empty($Alamat) || empty($NomorTelepon)) {
        $error = "Semua field harus diisi!";
    } else {
        $stmt = $mysqli->prepare("INSERT INTO `pelanggan`(`PelangganID`, `NamaPelanggan`, `Alamat`, `NomorTelepon`) VALUES (?, ?, ?, ?)");
        if ($stmt === false) {
            die("Error: " . $mysqli->error);
        }
        $stmt->bind_param("isss", $PelangganID, $NamaPelanggan, $Alamat, $NomorTelepon);
        if ($stmt->execute()) {
            header("Location:pelanggan.php");
            exit;
        } else {
            $error = "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Update data
if (isset($_POST['submit']) && $_POST['submit'] == 'Update') {
    $PelangganID = trim($_POST['PelangganID'] ?? '');
    $NamaPelanggan = trim($_POST['NamaPelanggan'] ?? '');
    $Alamat = trim($_POST['Alamat'] ?? '');
    $NomorTelepon = trim($_POST['NomorTelepon'] ?? '');

    // Validasi input
    if (empty($PelangganID) || empty($NamaPelanggan) || empty($Alamat) || empty($NomorTelepon)) {
        $error = "Semua field harus diisi!";
    } else {
        $stmt = $mysqli->prepare("UPDATE `pelanggan` SET `NamaPelanggan`=?, `Alamat`=?, `NomorTelepon`=? WHERE `PelangganID`=?");
        if ($stmt === false) {
            die("Error: " . $mysqli->error);
        }
        $stmt->bind_param("sssi", $NamaPelanggan, $Alamat, $NomorTelepon, $PelangganID);
        if ($stmt->execute()) {
            header("Location:pelanggan.php");
            exit;
        } else {
            $error = "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Hapus data
if (isset($_GET['hapus'])) {
    $PelangganID = trim($_GET['hapus']);
    $stmt = $mysqli->prepare("DELETE FROM `pelanggan` WHERE `PelangganID`=?");
    if ($stmt === false) {
        die("Error: " . $mysqli->error);
    }
    $stmt->bind_param("i", $PelangganID);
    if ($stmt->execute()) {
        header("Location:pelanggan.php");
        exit;
    } else {
        $error = "Error: " . $stmt->error;
    }
    $stmt->close();
}

// Edit data
$edit_data = null;
if (isset($_GET['edit'])) {
    $PelangganID = trim($_GET['edit']);
    $stmt = $mysqli->prepare("SELECT * FROM `pelanggan` WHERE `PelangganID`=?");
    if ($stmt === false) {
        die("Error: " . $mysqli->error);
    }
    $stmt->bind_param("i", $PelangganID);
    $stmt->execute();
    $edit_result = $stmt->get_result();
    $edit_data = $edit_result->fetch_array();
    $stmt->close();
}

$result = $mysqli->query("SELECT `PelangganID`, `NamaPelanggan`, `Alamat`, `NomorTelepon` FROM `pelanggan`");
if (!$result) {
    die("Query Error: " . $mysqli->error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pelanggan</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: #f4f6f9; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 20px; color: #333; }
        .container { max-width: 900px; margin: 0 auto; }
        h2 { font-size: 24px; margin-bottom: 20px; color: #2c3e50; font-weight: 600; }
        
        /* Form Styles */
        .form-container { background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); padding: 20px; margin-bottom: 20px; border: none; }
        .form-title { font-size: 16px; margin-bottom: 15px; font-weight: 700; color: #2c3e50; border-bottom: 2px solid #f0f0f0; padding-bottom: 10px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-size: 13px; margin-bottom: 5px; font-weight: 600; color: #555; }
        .form-group input, .form-group select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 13px; transition: border-color 0.3s; }
        .form-group input:focus, .form-group select:focus { outline: none; border-color: #4CAF50; box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.1); }
        
        /* Button Styles */
        .button-group { display: flex; gap: 10px; margin-top: 20px; }
        button, .btn-reset { 
            flex: 1; 
            padding: 10px 15px; 
            border: none; 
            border-radius: 6px; 
            font-size: 13px; 
            font-weight: 600; 
            cursor: pointer; 
            transition: all 0.3s ease; 
            text-transform: uppercase; 
            letter-spacing: 0.5px;
            text-align: center;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .btn-submit { 
            background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%); 
            color: white; 
            box-shadow: 0 4px 6px rgba(76, 175, 80, 0.2);
        }
        .btn-submit:hover { 
            background: linear-gradient(135deg, #45a049 0%, #388E3C 100%); 
            transform: translateY(-1px);
            box-shadow: 0 6px 12px rgba(76, 175, 80, 0.3);
        }
        
        .btn-reset { 
            background: #f5f5f5; 
            color: #666; 
            border: 1px solid #ddd;
        }
        .btn-reset:hover { 
            background: #e0e0e0; 
            color: #333;
        }

        /* Table Styles */
        .table-wrapper { background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); overflow: hidden; border: none; margin-top: 20px; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #f8f9fa; padding: 12px 15px; text-align: left; font-size: 12px; font-weight: 700; color: #555; border-bottom: 2px solid #eee; }
        td { padding: 12px 15px; border-bottom: 1px solid #eee; font-size: 13px; color: #444; }
        tr:last-child td { border-bottom: none; }
        tr:hover { background: #f8f9fa; }
        
        /* Action Buttons */
        .action-buttons { display: flex; gap: 8px; }
        .btn-edit, .btn-delete { 
            padding: 6px 12px; 
            font-size: 11px; 
            border-radius: 4px; 
            text-decoration: none; 
            color: white; 
            font-weight: 600; 
            transition: all 0.2s; 
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            display: inline-block;
        }
        .btn-edit { background: #3498db; }
        .btn-edit:hover { background: #2980b9; transform: translateY(-1px); box-shadow: 0 4px 8px rgba(52, 152, 219, 0.3); }
        .btn-delete { background: #e74c3c; }
        .btn-delete:hover { background: #c0392b; transform: translateY(-1px); box-shadow: 0 4px 8px rgba(231, 76, 60, 0.3); }
        
        /* Footer */
        .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; }
        .footer button { 
            background: transparent; 
            padding: 0; 
            border: none; 
            box-shadow: none; 
            flex: none; 
            width: auto;
        }
        .footer a { 
            display: inline-block; 
            padding: 10px 25px; 
            background: #607d8b; 
            color: white; 
            text-decoration: none; 
            border-radius: 50px; 
            font-size: 13px; 
            font-weight: 600; 
            transition: all 0.3s; 
            box-shadow: 0 4px 6px rgba(56, 144, 188, 0.2);
        }
        .footer a:hover { 
            background: #6ebde2; 
            transform: translateY(-2px); 
            box-shadow: 0 6px 12px rgba(86, 176, 220, 0.3); 
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Data Pelanggan</h2>

        <!-- Form Tambah/Edit -->
        <div class="form-container">
            <div class="form-title"><?php echo isset($_GET['edit']) ? 'EDIT DATA PELANGGAN' : 'TAMBAH DATA PELANGGAN'; ?></div>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="NamaPelanggan">Nama Pelanggan</label>
                    <input type="text" id="NamaPelanggan" name="NamaPelanggan" 
                        value="<?php echo isset($edit_data) && $edit_data ? $edit_data['NamaPelanggan'] : ''; ?>" required>
                </div>
                <div class="form-group">
                    <label for="Alamat">Alamat</label>
                    <input type="text" id="Alamat" name="Alamat" 
                        value="<?php echo isset($edit_data) && $edit_data ? $edit_data['Alamat'] : ''; ?>" required>
                </div>
                <div class="form-group">
                    <label for="NomorTelepon">Nomor Telepon</label>
                    <input type="text" id="NomorTelepon" name="NomorTelepon" 
                        value="<?php echo isset($edit_data) && $edit_data ? $edit_data['NomorTelepon'] : ''; ?>" required>
                </div>
                <div class="button-group">
                    <button type="submit" name="submit" value="<?php echo isset($_GET['edit']) ? 'Update' : 'Tambah'; ?>" class="btn-submit">
                        <?php echo isset($_GET['edit']) ? 'Update' : 'Tambah'; ?>
                    </button>
                    <button type="reset" class="btn-reset">Reset</button>
                    <?php if(isset($_GET['edit'])): ?>
                        <a href="pelanggan.php" class="btn-reset" style="text-align: center; line-height: 36px;">Batal</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Tabel Data -->
        <div class="table-wrapper">
            <table class="table">
                <thead>
                    <tr>
                        <th>Id pelanggan</th>
                        <th>Nama Pelanggan</th>
                        <th>Alamat</th>
                        <th>Nomor Telepon</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($pelanggan_data = $result->fetch_array()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($pelanggan_data['PelangganID']) . "</td>";
                        echo "<td>" . htmlspecialchars($pelanggan_data['NamaPelanggan']) . "</td>";
                        echo "<td>" . htmlspecialchars($pelanggan_data['Alamat']) . "</td>";
                        echo "<td>" . htmlspecialchars($pelanggan_data['NomorTelepon']) . "</td>";
                        echo "<td>";
                        echo "<div class='action-buttons'>";
                        echo "<a href='pelanggan.php?edit=" . htmlspecialchars($pelanggan_data['PelangganID']) . "' class='btn-edit'>Edit</a>";
                        echo "<a href='pelanggan.php?hapus=" . htmlspecialchars($pelanggan_data['PelangganID']) . "' class='btn-delete' onclick='return confirm(\"Yakin ingin menghapus?\")'>Hapus</a>";
                        echo "</div>";
                        echo "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <div class="footer">
            <button><a href="../index.php">Kembali ke Menu Utama</a></button>
        </div>
    </div>
</body>
</html>
