<?php
include("../koneksi.php");

// API Endpoint untuk mendapatkan data dalam format JSON
if (isset($_GET['action']) && $_GET['action'] == 'get') {
    header('Content-Type: application/json');
    $result = $mysqli->query("SELECT `ProdukID`, `NamaProduk`, `Harga`, `Stok` FROM `produk` ORDER BY `ProdukID`");
    
    if (!$result) {
        echo json_encode([]);
        exit;
    }
    
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $row['ProdukID'] = (int)$row['ProdukID'];
        $row['Harga'] = (int)$row['Harga'];
        $row['Stok'] = (int)$row['Stok'];
        $data[] = $row;
    }
    
    echo json_encode($data);
    exit;
}

// Tambah data
if (isset($_POST['submit']) && $_POST['submit'] == 'Tambah') {
    $ProdukID = trim($_POST['ProdukID'] ?? '');
    $NamaProduk = trim($_POST['NamaProduk'] ?? '');
    $Harga = $_POST['Harga'] ?? 0;
    $Stok = $_POST['Stok'] ?? 0;

    // Validasi input
    if (empty($ProdukID) || empty($NamaProduk) || $Harga < 0 || $Stok < 0) {
        $error = "Semua field harus diisi dengan benar!";
    } else {
        $stmt = $mysqli->prepare("INSERT INTO `produk` (`ProdukID`, `NamaProduk`, `Harga`, `Stok`) VALUES (?, ?, ?, ?)");
        if ($stmt === false) {
            die("Error: " . $mysqli->error);
        }
        $stmt->bind_param("isdi", $ProdukID, $NamaProduk, $Harga, $Stok);
        if ($stmt->execute()) {
            header("Location:produk.php");
            exit;
        } else {
            $error = "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Update data
if (isset($_POST['submit']) && $_POST['submit'] == 'Update') {
    $ProdukID = trim($_POST['ProdukID'] ?? '');
    $NamaProduk = trim($_POST['NamaProduk'] ?? '');
    $Harga = $_POST['Harga'] ?? 0;
    $Stok = $_POST['Stok'] ?? 0;

    // Validasi input
    if (empty($ProdukID) || empty($NamaProduk) || $Harga < 0 || $Stok < 0) {
        $error = "Semua field harus diisi dengan benar!";
    } else {
        $stmt = $mysqli->prepare("UPDATE `produk` SET `NamaProduk`=?, `Harga`=?, `Stok`=? WHERE `ProdukID`=?");
        if ($stmt === false) {
            die("Error: " . $mysqli->error);
        }
        $stmt->bind_param("sdii", $NamaProduk, $Harga, $Stok, $ProdukID);
        if ($stmt->execute()) {
            header("Location:produk.php");
            exit;
        } else {
            $error = "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Hapus data
if (isset($_GET['hapus'])) {
    $ProdukID = trim($_GET['hapus']);
    $stmt = $mysqli->prepare("DELETE FROM `produk` WHERE `ProdukID`=?");
    if ($stmt === false) {
        die("Error: " . $mysqli->error);
    }
    $stmt->bind_param("i", $ProdukID);
    if ($stmt->execute()) {
        header("Location:produk.php");
        exit;
    } else {
        $error = "Error: " . $stmt->error;
    }
    $stmt->close();
}

// Edit data
$edit_data = null;
if (isset($_GET['edit'])) {
    $ProdukID = trim($_GET['edit']);
    $stmt = $mysqli->prepare("SELECT * FROM `produk` WHERE `ProdukID`=?");
    if ($stmt === false) {
        die("Error: " . $mysqli->error);
    }
    $stmt->bind_param("i", $ProdukID);
    $stmt->execute();
    $edit_result = $stmt->get_result();
    $edit_data = $edit_result->fetch_array();
    $stmt->close();
}

$result = $mysqli->query("SELECT `ProdukID`, `NamaProduk`, `Harga`, `Stok` FROM `produk`");
if (!$result) {
    die("Query Error: " . $mysqli->error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produk yang tersedia di database</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: #f4f6f9; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 20px; color: #333; }
        .container { max-width: 900px; margin: 0 auto; }
        h2 { font-size: 24px; margin-bottom: 20px; color: #2c3e50; font-weight: 600; }
        
        /* Form Styles */
        .form-container { background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); padding: 20px; margin-bottom: 20px; border: none; }
        .form-title { font-size: 16px; margin-bottom: 15px; font-weight: 700; color: #2c3e50; border-bottom: 2px solid #f0f0f0; padding-bottom: 10px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-size: 13px; margin-bottom: 5px; font-weight: 600; color: #555; }
        .form-group input, .form-group select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 13px; transition: border-color 0.3s; }
        .form-group input:focus, .form-group select:focus { outline: none; border-color: #4CAF50; box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.1); }
        
        /* Button Styles */
        .button-group { display: flex; gap: 10px; margin-top: 20px; }
        button, .btn-reset { 
            flex: 1; 
            padding: 10px 15px; 
            border: none; 
            border-radius: 6px; 
            font-size: 13px; 
            font-weight: 600; 
            cursor: pointer; 
            transition: all 0.3s ease; 
            text-transform: uppercase; 
            letter-spacing: 0.5px;
            text-align: center;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .btn-submit { 
            background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%); 
            color: white; 
            box-shadow: 0 4px 6px rgba(76, 175, 80, 0.2);
        }
        .btn-submit:hover { 
            background: linear-gradient(135deg, #45a049 0%, #388E3C 100%); 
            transform: translateY(-1px);
            box-shadow: 0 6px 12px rgba(76, 175, 80, 0.3);
        }
        
        .btn-reset { 
            background: #f5f5f5; 
            color: #666; 
            border: 1px solid #ddd;
        }
        .btn-reset:hover { 
            background: #e0e0e0; 
            color: #333;
        }

        /* Table Styles */
        .table-wrapper { background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); overflow: hidden; border: none; margin-top: 20px; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #f8f9fa; padding: 12px 15px; text-align: left; font-size: 12px; font-weight: 700; color: #555; border-bottom: 2px solid #eee; }
        td { padding: 12px 15px; border-bottom: 1px solid #eee; font-size: 13px; color: #444; }
        tr:last-child td { border-bottom: none; }
        tr:hover { background: #f8f9fa; }
        
        /* Action Buttons */
        .action-buttons { display: flex; gap: 8px; }
        .btn-edit, .btn-delete { 
            padding: 6px 12px; 
            font-size: 11px; 
            border-radius: 4px; 
            text-decoration: none; 
            color: white; 
            font-weight: 600; 
            transition: all 0.2s; 
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            display: inline-block;
        }
        .btn-edit { background: #3498db; }
        .btn-edit:hover { background: #2980b9; transform: translateY(-1px); box-shadow: 0 4px 8px rgba(52, 152, 219, 0.3); }
        .btn-delete { background: #e74c3c; }
        .btn-delete:hover { background: #c0392b; transform: translateY(-1px); box-shadow: 0 4px 8px rgba(231, 76, 60, 0.3); }
        
        /* Footer */
        .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; }
        .footer button { 
            background: transparent; 
            padding: 0; 
            border: none; 
            box-shadow: none; 
            flex: none; 
            width: auto;
        }
        .footer a { 
            display: inline-block; 
            padding: 10px 25px; 
            background: #607d8b; 
            color: white; 
            text-decoration: none; 
            border-radius: 50px; 
            font-size: 13px; 
            font-weight: 600; 
            transition: all 0.3s; 
            box-shadow: 0 4px 6px rgba(56, 144, 188, 0.2);
        }
        .footer a:hover { 
            background: #6ebde2; 
            transform: translateY(-2px); 
            box-shadow: 0 6px 12px rgba(86, 176, 220, 0.3); 
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Produk yang tersedia di database</h2>

        <!-- Form Tambah/Edit -->
        <div class="form-container">
            <div class="form-title"><?php echo isset($_GET['edit']) ? 'EDIT DATA PRODUK' : 'TAMBAH DATA PRODUK'; ?></div>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="ProdukID">ID Produk</label>
                    <input type="text" id="ProdukID" name="ProdukID" 
                        value="<?php echo $edit_data ? $edit_data['ProdukID'] : ''; ?>" 
                        <?php echo isset($_GET['edit']) ? 'readonly' : ''; ?> required>
                </div>
                <div class="form-group">
                    <label for="NamaProduk">Nama Produk</label>
                    <input type="text" id="NamaProduk" name="NamaProduk" 
                        value="<?php echo $edit_data ? $edit_data['NamaProduk'] : ''; ?>" required>
                </div>
                <div class="form-group">
                    <label for="Harga">Harga</label>
                    <input type="number" id="Harga" name="Harga" 
                        value="<?php echo $edit_data ? $edit_data['Harga'] : ''; ?>" required>
                </div>
                <div class="form-group">
                    <label for="Stok">Stok</label>
                    <input type="number" id="Stok" name="Stok" 
                        value="<?php echo $edit_data ? $edit_data['Stok'] : ''; ?>" required>
                </div>
                <div class="button-group">
                    <button type="submit" name="submit" value="<?php echo isset($_GET['edit']) ? 'Update' : 'Tambah'; ?>" class="btn-submit">
                        <?php echo isset($_GET['edit']) ? 'Update' : 'Tambah'; ?>
                    </button>
                    <button type="reset" class="btn-reset">Reset</button>
                    <?php if(isset($_GET['edit'])): ?>
                        <a href="produk.php" class="btn-reset" style="text-align: center; line-height: 36px;">Batal</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Tabel Data -->
        <div class="table-wrapper">
            <table class="table">
                <thead>
                    <tr>
                        <th>Produk ID</th>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($produk_data = $result->fetch_array()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($produk_data['ProdukID']) . "</td>";
                        echo "<td>" . htmlspecialchars($produk_data['NamaProduk']) . "</td>";
                        echo "<td>Rp " . number_format($produk_data['Harga'], 0, ',', '.') . "</td>";
                        echo "<td><span style='color: #00ff88; font-weight: 600;'>" . $produk_data['Stok'] . "</span></td>";
                        echo "<td>";
                        echo "<div class='action-buttons'>";
                        echo "<a href='produk.php?edit=" . htmlspecialchars($produk_data['ProdukID']) . "' class='btn-edit'>Edit</a>";
                        echo "<a href='produk.php?hapus=" . htmlspecialchars($produk_data['ProdukID']) . "' class='btn-delete' onclick='return confirm(\"Yakin ingin menghapus?\")'>Hapus</a>";
                        echo "</div>";
                        echo "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <div class="footer">
            <button><a href="../index.php">Kembali ke Menu Utama</a></button>
        </div>
    </div>
</body>
</html>