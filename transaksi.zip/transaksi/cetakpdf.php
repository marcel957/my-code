<?php
include_once("koneksi.php");
$result_join = $mysqli->query("
SELECT
    pj.PenjualanID,
    pl.PelangganID,
    pj.TanggalPenjualan,
    pr.ProdukID,
    dp.JumlahProduk,
    dp.Subtotal
FROM penjualan AS pj
INNER JOIN pelanggan AS pl 
    ON pj.PelangganID = pl.PelangganID
INNER JOIN detailpenjualan AS dp 
    ON pj.PenjualanID = dp.PenjualanID
INNER JOIN produk AS pr 
    ON dp.ProdukID = pr.ProdukID;");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Cetak Data Penjualan</title>

<style>
body{
    font-family: Arial;
    font-size:12px;
}
h2{
    text-align:center;
    margin-bottom:5px;
}
p{
    text-align:center;
    margin-top:0;
}
table{
    width:100%;
    border-collapse:collapse;
    margin-top:15px;
}
th,td{
    border:1px solid black;
    padding:6px;
    text-align:center;
}
th{
    background:#eee;
}
.footer{
    margin-top:40px;
    text-align:right;
}

</style>

</head>
<body onload="window.print()">

<h2>LAPORAN DATA PENJUALAN</h2>
<p>toko marcel</p>
<table>
    <tr>
        <th></th>
        <th>ID Penjualan</th>
        <th>ID Pelanggan</th>
        <th>Tanggal Penjualan</th>
        <th>ID Produk</th>
        <th>Jumlah</th>
        <th>Subtotal</th>
    </tr>

<?php
$no = 1;
$total = 0;

if($result_join->num_rows > 0){
    while($row = $result_join->fetch_assoc()){
        $total += $row['Subtotal'];
?>
<tr>
    <td><?= $no++; ?></td>
    <td><?= $row['PenjualanID']; ?></td>
    <td><?= $row['PelangganID']; ?></td>
    <td><?= $row['TanggalPenjualan']; ?></td>
    <td><?= $row['ProdukID']; ?></td>
    <td><?= $row['JumlahProduk']; ?></td>
    <td>Rp <?= number_format($row['Subtotal'],0,',','.'); ?></td>
</tr>
<?php
    }
}else{
    echo "<tr><td colspan='7'>Data tidak tersedia</td></tr>";
}
?>
<tr>
    <th colspan="6">TOTAL</th>
    <th>Rp <?= number_format($total,0,',','.'); ?></th>
</tr>
</table>

<div class="footer">
    <p><?= date('d-m-Y'); ?><br>Hasil</p>
</div>
</body>
</html>