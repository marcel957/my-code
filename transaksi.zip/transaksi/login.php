<?php
session_start();
define('APP_USER', 'marcel');
define('APP_PASS', 'marcelleno');
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit;
}
if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true) {
    header('Location: index.php');
    exit;
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($username === '' || $password === '') {
        $error = 'Username dan password harus diisi.';
    } elseif ($username === APP_USER && $password === APP_PASS) {
        $_SESSION['user_logged_in'] = true;
        $_SESSION['username'] = $username;
        header('Location: index.php');
        exit;
    } else {
        $error = 'Username atau password salah.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Aplikasi Kasir</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            background: #f9f9f9;
            font-family: Arial, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-card {
            background: white;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 40px 32px;
            width: 100%;
            max-width: 380px;
        }
        .login-header {
            background: #2c3e50;
            color: white;
            padding: 15px;
            border-radius: 4px;
            text-align: center;
            margin-bottom: 24px;
        }
        .login-header h1 { font-size: 20px; margin-bottom: 4px; }
        .login-header p { font-size: 12px; opacity: 0.9; }
        .form-group { margin-bottom: 16px; }
        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: bold;
            color: #333;
            margin-bottom: 6px;
        }
        .form-group input {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ddd;
            border-radius: 3px;
            font-size: 14px;
            font-family: Arial, sans-serif;
            outline: none;
            transition: border-color 0.3s;
        }
        .form-group input:focus {
            border-color: #2c3e50;
        }
        .btn-login {
            width: 100%;
            padding: 10px;
            background: #2c3e50;
            border: none;
            border-radius: 3px;
            color: white;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s;
            margin-top: 4px;
        }
        .btn-login:hover { background: #34495e; }
        .alert {
            background: #fdecea;
            border: 1px solid #f5c6cb;
            color: #c0392b;
            padding: 10px;
            border-radius: 3px;
            font-size: 13px;
            margin-top: 16px;
            text-align: center;
        }
        .footer-text {
            text-align: center;
            margin-top: 20px;
            font-size: 11px;
            color: #999;
        }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="login-header">
            <h1>💳 Aplikasi Kasir</h1>
            <p>Silakan login untuk melanjutkan</p>
        </div>
        <form method="post" autocomplete="off">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username"
                    value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                    placeholder="Username" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button class="btn-login" type="submit">Login</button>
        </form>
        <?php if ($error): ?>
            <div class="alert"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <div class="footer-text">© 2026 Aplikasi Kasir</div>
    </div>
</body>
</html>
