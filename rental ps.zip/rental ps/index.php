<?php
session_start();
define('APP_USER', 'marcel');
define('APP_PASS', 'marcelleno123');
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit;
}
if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true) {
    header('Location: dashboard.php');
    exit;
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    if ($username === '' || $password === '') {
        $error = 'Username dan password harus diisi.';
    } elseif ($username === APP_USER && $password === APP_PASS) {
        $_SESSION['user_logged_in'] = true;
        $_SESSION['username'] = $username;
        header('Location: index.php');
        exit;
    } else {
        $error = 'Username atau password salah.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Aplikasi rental</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Outfit', sans-serif; }
        body {
            background-color: #000;
            color: #fff;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }
        /* 3D Canvas Background */
        #canvas3d {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
        }
        .login-card {
            background: transparent;
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 12px;
            padding: 40px 32px;
            width: 100%;
            max-width: 380px;
            z-index: 1;
            backdrop-filter: blur(8px);
        }
        .login-header {
            background: transparent;
            color: white;
            padding: 10px;
            text-align: center;
            margin-bottom: 24px;
        }
        .login-header h1 { font-size: 24px; margin-bottom: 8px; font-weight: 700; }
        .login-header p { font-size: 14px; color: #ccc; }
        .form-group { margin-bottom: 20px; }
        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: #ccc;
            margin-bottom: 8px;
        }
        .form-group input {
            width: 100%;
            padding: 12px 16px;
            background: transparent;
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 8px;
            font-size: 15px;
            color: white;
            font-family: 'Outfit', sans-serif;
            outline: none;
            transition: all 0.3s;
        }
        .form-group input::placeholder {
            color: rgba(255, 255, 255, 0.4);
        }
        .form-group input:focus {
            border-color: #fff;
            box-shadow: 0 0 10px rgba(255, 255, 255, 0.2);
        }
        .btn-login {
            width: 100%;
            padding: 14px;
            background: transparent;
            border: 1px solid #fff;
            border-radius: 8px;
            color: white;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 8px;
        }
        .btn-login:hover { 
            background: rgba(255, 255, 255, 0.1);
            box-shadow: 0 0 15px rgba(255, 255, 255, 0.5);
        }
        .alert {
            background: rgba(231, 76, 60, 0.1);
            border: 1px solid rgba(231, 76, 60, 0.5);
            color: #ff7675;
            padding: 12px;
            border-radius: 8px;
            font-size: 14px;
            margin-top: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <canvas id="canvas3d"></canvas>

    <div class="login-card">
        <div class="login-header">
            <h1>Aplikasi Rental PS</h1>
            <p>Silakan login untuk melanjutkan</p>
        </div>
        <form method="post" autocomplete="off">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username"
                    value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                    placeholder="Masukkan username" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Masukkan password" required>
            </div>
            <button class="btn-login" type="submit">Login</button>
        </form>
        <?php if ($error): ?>
            <div class="alert"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
    </div>
        <script type="importmap">
        {
            "imports": {
                "@splinetool/runtime": "https://unpkg.com/@splinetool/runtime@1.0.94/build/runtime.js"
            }
        }
    </script>
    <script type="module" src="script.js"></script>
</body>
</html>