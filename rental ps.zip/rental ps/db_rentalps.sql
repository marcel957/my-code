-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2026 at 05:32 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_rentalps`
--

-- --------------------------------------------------------

--
-- Table structure for table `game`
--

CREATE TABLE `game` (
  `nama_game` varchar(255) NOT NULL,
  `id_game` int(11) NOT NULL,
  `jenis_game` varchar(255) NOT NULL,
  `kategori` int(255) NOT NULL,
  `jenis_ps` enum('Ps5','Ps4','Ps3','ps2') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `game`
--

INSERT INTO `game` (`nama_game`, `id_game`, `jenis_game`, `kategori`, `jenis_ps`) VALUES
('cyberpunk2077', 1, 'adventure', 1, 'Ps5');

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE `karyawan` (
  `nama` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `no_id` int(255) NOT NULL,
  `operation1` tinyint(255) NOT NULL,
  `no_hp` varchar(255) NOT NULL,
  `jenis_kelamin` enum('laki-laki','perempuan','') NOT NULL,
  `username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Role` enum('karyawan','owner','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`nama`, `alamat`, `no_id`, `operation1`, `no_hp`, `jenis_kelamin`, `username`, `Password`, `Role`) VALUES
('marcel', 'kulim jaya', 1, 1, '085363221389', 'laki-laki', 'marcel', 'marcel1', 'owner');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `nama` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `no_hp` varchar(255) NOT NULL,
  `no_pelanggan` int(255) NOT NULL,
  `jenis_kelamin` enum('laki_laki','perempuan','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`nama`, `alamat`, `no_hp`, `no_pelanggan`, `jenis_kelamin`) VALUES
('bentar arya langga', 'baskem', '081271883452', 1, 'laki_laki');

-- --------------------------------------------------------

--
-- Table structure for table `rental`
--

CREATE TABLE `rental` (
  `jam_masuk` datetime NOT NULL,
  `jam_keluar` datetime NOT NULL,
  `harga_sewa` decimal(10,2) NOT NULL,
  `no_transaksi` int(255) NOT NULL,
  `no_id` int(255) NOT NULL,
  `jenis_ps` enum('Ps5','Ps4','Ps3','Ps2') NOT NULL,
  `no_pelanggan` int(255) NOT NULL,
  `id_game` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rental`
--

INSERT INTO `rental` (`jam_masuk`, `jam_keluar`, `harga_sewa`, `no_transaksi`, `no_id`, `jenis_ps`, `no_pelanggan`, `id_game`) VALUES
('2026-02-26 12:00:00', '2026-02-26 13:00:00', 10000.00, 1, 1, 'Ps5', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `game`
--
ALTER TABLE `game`
  ADD PRIMARY KEY (`id_game`),
  ADD KEY `jenis_ps` (`jenis_ps`);

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`no_id`),
  ADD KEY `no_hp` (`no_hp`),
  ADD KEY `Role` (`Role`),
  ADD KEY `jenis_kelamin` (`jenis_kelamin`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`no_pelanggan`),
  ADD KEY `no_hp` (`no_hp`),
  ADD KEY `jenis_kelamin` (`jenis_kelamin`);

--
-- Indexes for table `rental`
--
ALTER TABLE `rental`
  ADD PRIMARY KEY (`no_transaksi`),
  ADD KEY `no_id` (`no_id`),
  ADD KEY `jenis_ps` (`jenis_ps`),
  ADD KEY `no_pelanggan` (`no_pelanggan`),
  ADD KEY `id_game` (`id_game`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `karyawan`
--
ALTER TABLE `karyawan`
  MODIFY `no_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `no_pelanggan` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rental`
--
ALTER TABLE `rental`
  ADD CONSTRAINT `rental_ibfk_1` FOREIGN KEY (`jenis_ps`) REFERENCES `game` (`jenis_ps`),
  ADD CONSTRAINT `rental_ibfk_2` FOREIGN KEY (`no_pelanggan`) REFERENCES `pelanggan` (`no_pelanggan`),
  ADD CONSTRAINT `rental_ibfk_3` FOREIGN KEY (`no_id`) REFERENCES `karyawan` (`no_id`),
  ADD CONSTRAINT `rental_ibfk_4` FOREIGN KEY (`id_game`) REFERENCES `game` (`id_game`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
