<?php
include '../koneksi.php';
// Start session to check login status
session_start();

if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header('Location: ../index.php');
    exit;
}

function esc($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

if (isset($_GET['delete'])) {
    $no = (int) $_GET['delete'];

    if ($no > 0) {
        mysqli_query($mysqli, "DELETE FROM karyawan WHERE no_id = '$no'");
    }

    header('Location: karyawan.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama'] ?? '');
    $alamat = trim($_POST['alamat'] ?? '');
    $no_hp = trim($_POST['no_hp'] ?? '');
    $operation1 = (int) ($_POST['operation1'] ?? 0);
    $jenis_kelamin = trim($_POST['jenis_kelamin'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['Password'] ?? '');
    $role = trim($_POST['Role'] ?? '');
    $old_no = (int) ($_POST['old_no'] ?? 0);

    $nama = mysqli_real_escape_string($mysqli, $nama);
    $alamat = mysqli_real_escape_string($mysqli, $alamat);
    $no_hp = mysqli_real_escape_string($mysqli, $no_hp);
    $jenis_kelamin = mysqli_real_escape_string($mysqli, $jenis_kelamin);
    $username = mysqli_real_escape_string($mysqli, $username);
    $password = mysqli_real_escape_string($mysqli, $password);
    $role = mysqli_real_escape_string($mysqli, $role);

    $opsi_jk = array('laki-laki', 'perempuan');
    $opsi_role = array('karyawan', 'owner');

    if (!in_array($jenis_kelamin, $opsi_jk, true)) {
        $jenis_kelamin = '';
    }

    if (!in_array($role, $opsi_role, true)) {
        $role = '';
    }

    if (
        $nama !== '' &&
        $alamat !== '' &&
        $no_hp !== '' &&
        $operation1 >= 0 &&
        $jenis_kelamin !== '' &&
        $username !== '' &&
        $password !== '' &&
        $role !== ''
    ) {
        if ($old_no > 0) {
            $edit = "UPDATE karyawan SET
                nama='$nama',
                alamat='$alamat',
                no_hp='$no_hp',
                operation1='$operation1',
                jenis_kelamin='$jenis_kelamin',
                username='$username',
                Password='$password',
                Role='$role'
                WHERE no_id='$old_no'";
        } else {
            $edit = "INSERT INTO karyawan
                (nama, alamat, no_hp, operation1, jenis_kelamin, username, Password, Role)
                VALUES
                ('$nama', '$alamat', '$no_hp', '$operation1', '$jenis_kelamin', '$username', '$password', '$role')";
        }

        mysqli_query($mysqli, $edit);
    }

    header('Location: karyawan.php');
    exit;
}

$data_edit = null;
if (isset($_GET['edit'])) {
    $id_edit = (int) $_GET['edit'];

    if ($id_edit > 0) {
        $hasil = mysqli_query($mysqli, "SELECT * FROM karyawan WHERE no_id='$id_edit'");
        $data_edit = mysqli_fetch_assoc($hasil);
    }
}

$daftar_karyawan = mysqli_query($mysqli, "SELECT * FROM karyawan ORDER BY no_id ASC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Karyawan</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Outfit', sans-serif;
}
body {
    background: #000;
    color: #fff;
    padding: 20px;
    overflow-x: hidden;
}
#canvas3d {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: -1;
}
.container {
    max-width: 900px;
    margin: 0 auto;
    background: rgba(255, 255, 255, 0.03);
    backdrop-filter: blur(5px);
    border-radius: 12px;
    padding: 30px;
    border: 1px solid rgba(255, 255, 255, 0.1);
}
h1 {
    font-size: 1.8rem;
    font-weight: 600;
    margin-bottom: 30px;
    text-align: center;
    letter-spacing: 1px;
}
h3 {
    font-size: 1.1rem;
    font-weight: 400;
    margin-bottom: 20px;
    opacity: 0.8;
}
.form-section {
    margin-bottom: 40px;
    padding-bottom: 20px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}
.grid-inputs {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
}
label {
    display: block;
    font-size: 0.8rem;
    opacity: 0.6;
    margin-bottom: 5px;
}
input, select, textarea {
    width: 100%;
    background: transparent;
    border: none;
    border-bottom: 1px solid rgba(255, 255, 255, 0.2);
    padding: 10px 0;
    color: #fff;
    outline: none;
    transition: 0.3s;
    margin-bottom: 20px;
}
input:focus, select:focus, textarea:focus {
    border-bottom-color: #fff;
}
option {
    background: #111;
    color: #fff;
}
.btn {
    background: #fff;
    color: #000;
    border: none;
    padding: 12px 25px;
    border-radius: 4px;
    font-weight: 600;
    cursor: pointer;
    transition: 0.3s;
    width: 100%;
    margin-top: 10px;
}
.btn:hover {
    background: #ccc;
    transform: translateY(-1px);
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}
th {
    text-align: left;
    font-size: 0.75rem;
    text-transform: uppercase;
    opacity: 0.5;
    padding: 15px 10px;
    font-weight: 400;
}
td {
    padding: 15px 10px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    font-size: 0.9rem;
}
.action-links a {
    text-decoration: none;
    font-size: 0.8rem;
    margin-right: 10px;
    transition: 0.3s;
}
.edit {
    color: #fff;
    opacity: 0.6;
}
.delete {
    color: #ff5555;
    opacity: 0.6;
}
.action-links a:hover {
    opacity: 1;
}
.nav {
    margin-bottom: 20px;
}
.nav a {
    color: #fff;
    text-decoration: none;
    font-size: 0.85rem;
    opacity: 0.5;
    transition: 0.3s;
}
.nav a:hover {
    opacity: 1;
}
    </style>
</head>
<body>
    <canvas id="canvas3d"></canvas>
    <div class="container">
        <div class="nav">
            <a href="../dashboard.php">kembali</a>
        </div>
        
        <h1>Data Pegawai</h1>
        <div class="form-section">
            <h3><?php echo $data_edit ? 'Edit Staff Profile' : 'tambahkan pegawai'; ?></h3>
            <form method="post">
                <input type="hidden" name="old_no" value="<?= esc($data_edit['no_id'] ?? '') ?>">
                
                <div class="grid-inputs">
                    <div>
                        <label>Name</label>
                        <input type="text" name="nama" value="<?= esc($data_edit['nama'] ?? '') ?>" required>
                    </div>
                    <div>
                        <label>Ponsel</label>
                        <input type="text" name="no_hp" value="<?= esc($data_edit['no_hp'] ?? '') ?>" required>
                    </div>
                </div>
                <div class="grid-inputs">
                    <div>
                        <label>Operation ID</label>
                        <input type="number" name="operation1" value="<?= esc($data_edit['operation1'] ?? '') ?>" required>
                    </div>
                    <div>
                        <label>Gender</label>
                        <select name="jenis_kelamin" required>
                            <option value="">Select</option>
                            <option value="laki-laki" <?= ($data_edit && $data_edit['jenis_kelamin']=='laki-laki') ? 'selected' : '' ?>>Male</option>
                            <option value="perempuan" <?= ($data_edit && $data_edit['jenis_kelamin']=='perempuan') ? 'selected' : '' ?>>Female</option>
                        </select>
                    </div>
                </div>
                <div class="grid-inputs">
                    <div>
                        <label>Username</label>
                        <input type="text" name="username" value="<?= esc($data_edit['username'] ?? '') ?>" required>
                    </div>
                    <div>
                        <label>Password</label>
                        <input type="text" name="Password" value="<?= esc($data_edit['Password'] ?? '') ?>" required>
                    </div>
                    <div>
                        <label>Role</label>
                        <select name="Role" required>
                            <option value="">Select Role</option>
                            <option value="karyawan" <?= ($data_edit && $data_edit['Role']=='karyawan') ? 'selected' : '' ?>>Staff</option>
                            <option value="owner" <?= ($data_edit && $data_edit['Role']=='owner') ? 'selected' : '' ?>>Owner</option>
                        </select>
                    </div>
                </div>
                <label>alamat</label>
                <textarea name="alamat" rows="2" required><?= esc($data_edit['alamat'] ?? '') ?></textarea>
                <button type="submit" class="btn">Update</button>
                <?php if ($data_edit): ?>
                    <a href="karyawan.php" style="display:block; text-align:center; margin-top:15px; font-size:0.8rem; color:#fff; opacity:0.5; text-decoration:none;">Cancel</a>
                <?php endif; ?>
            </form>
        </div>
        <h3>Active Team</h3>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Profile</th>
                    <th>Info akun</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $n = 1;
                while ($r = mysqli_fetch_assoc($daftar_karyawan)): 
                    $jk_label = ($r['jenis_kelamin']=='laki-laki') ? 'M' : 'F';
                ?>
                <tr>
                    <td><?= $n++ ?></td>
                    <td>
                        <strong><?= esc($r['nama']) ?></strong> <small style="opacity:0.3">[<?= esc($jk_label) ?>]</small><br>
                        <small style="opacity:0.6"><?= esc($r['no_hp']) ?></small>
                    </td>
                    <td>
                        <span style="opacity:0.7"><?= esc(ucfirst($r['Role'])) ?></span><br>
                        <small style="opacity:0.4">User: <?= esc($r['username']) ?></small>
                    </td>
                    <td class="action-links">
                        <a href="?edit=<?= esc($r['no_id']) ?>" class="edit">Edit</a>
                        <a href="?delete=<?= esc($r['no_id']) ?>" class="delete" onclick="return confirm('Delete staff profile?')">Remove</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <script type="importmap">
        {
            "imports": {
                "@splinetool/runtime": "https://unpkg.com/@splinetool/runtime@1.0.94/build/runtime.js"
            }
        }
    </script>
    <script type="module" src="../script.js"></script>
</body>
</html>
