<?php
include '../koneksi.php';
// Start session to check login status
session_start();

if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header('Location: ../index.php');
    exit;
}

function esc($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

if (isset($_GET['delete'])) {
    $no = (int) $_GET['delete'];

    if ($no > 0) {
        mysqli_query($mysqli, "DELETE FROM pelanggan WHERE no_pelanggan = '$no'");
    }

    header('Location: pelanggan.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama'] ?? '');
    $alamat = trim($_POST['alamat'] ?? '');
    $no_hp = trim($_POST['no_hp'] ?? '');
    $jenis_kelamin = trim($_POST['jenis_kelamin'] ?? '');
    $old_no = (int) ($_POST['old_no'] ?? 0);

    $nama = mysqli_real_escape_string($mysqli, $nama);
    $alamat = mysqli_real_escape_string($mysqli, $alamat);
    $no_hp = mysqli_real_escape_string($mysqli, $no_hp);
    $jenis_kelamin = mysqli_real_escape_string($mysqli, $jenis_kelamin);

    $opsi_jk = array('laki_laki', 'perempuan');
    if (!in_array($jenis_kelamin, $opsi_jk, true)) {
        $jenis_kelamin = '';
    }

    if ($nama !== '' && $alamat !== '' && $no_hp !== '' && $jenis_kelamin !== '') {
        if ($old_no > 0) {
            $update = "UPDATE pelanggan SET
                nama='$nama',
                alamat='$alamat',
                no_hp='$no_hp',
                jenis_kelamin='$jenis_kelamin'
                WHERE no_pelanggan='$old_no'";
        } else {
            $update = "INSERT INTO pelanggan
                (nama, alamat, no_hp, jenis_kelamin)
                VALUES
                ('$nama', '$alamat', '$no_hp', '$jenis_kelamin')";
        }

        mysqli_query($mysqli, $update);
    }

    header('Location: pelanggan.php');
    exit;
}

$edit = null;
if (isset($_GET['edit'])) {
    $id_edit = (int) $_GET['edit'];

    if ($id_edit > 0) {
        $hasil = mysqli_query($mysqli, "SELECT * FROM pelanggan WHERE no_pelanggan='$id_edit'");
        $edit = mysqli_fetch_assoc($hasil);
    }
}

$daftar_pelanggan = mysqli_query($mysqli, "SELECT * FROM pelanggan ORDER BY no_pelanggan ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Rental PS - Customers</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Outfit', sans-serif;
}
body {
    background: #000;
    color: #fff;
    padding: 20px;
    overflow-x: hidden;
}
#canvas3d {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: -1;
}
.container {
    max-width: 800px;
    margin: 0 auto;
    background: rgba(255, 255, 255, 0.03);
    backdrop-filter: blur(5px);
    border-radius: 12px;
    padding: 30px;
    border: 1px solid rgba(255, 255, 255, 0.1);
}
h1 {
    font-size: 1.8rem;
    font-weight: 600;
    margin-bottom: 30px;
    text-align: center;
    letter-spacing: 1px;
}
h3 {
    font-size: 1.1rem;
    font-weight: 400;
    margin-bottom: 20px;
    opacity: 0.8;
}
.form-section {
    margin-bottom: 40px;
    padding-bottom: 20px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}
.grid-inputs {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}
label {
    display: block;
    font-size: 0.8rem;
    opacity: 0.6;
    margin-bottom: 5px;
}
input, select, textarea {
    width: 100%;
    background: transparent;
    border: none;
    border-bottom: 1px solid rgba(255, 255, 255, 0.2);
    padding: 10px 0;
    color: #fff;
    outline: none;
    transition: 0.3s;
    margin-bottom: 20px;
}
input:focus, select:focus, textarea:focus {
    border-bottom-color: #fff;
}
option {
    background: #111;
    color: #fff;
}
.btn {
    background: #fff;
    color: #000;
    border: none;
    padding: 12px 25px;
    border-radius: 4px;
    font-weight: 600;
    cursor: pointer;
    transition: 0.3s;
    width: 100%;
    margin-top: 10px;
}
.btn:hover {
    background: #ccc;
    transform: translateY(-1px);
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}
th {
    text-align: left;
    font-size: 0.75rem;
    text-transform: uppercase;
    opacity: 0.5;
    padding: 15px 10px;
    font-weight: 400;
}
td {
    padding: 15px 10px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    font-size: 0.9rem;
}
.action-links a {
    text-decoration: none;
    font-size: 0.8rem;
    margin-right: 10px;
    transition: 0.3s;
}
.edit {
    color: #fff;
    opacity: 0.6;
}
.delete {
    color: #ff5555;
    opacity: 0.6;
}
.action-links a:hover {
    opacity: 1;
}
    .nav {
    margin-bottom: 20px;
}
    .nav a {
    color: #fff;
    text-decoration: none;
    font-size: 0.85rem;
    opacity: 0.5;
    transition: 0.3s;
}
    .nav a:hover {
    opacity: 1;
}
    </style>
</head>
<body>
    <canvas id="canvas3d"></canvas>

    <div class="container">
        <div class="nav">
            <a href="../dashboard.php">← kembali</a>
        </div>
        
        <h1>pelanggan</h1>

        <div class="form-section">
            <h3><?php echo $edit ? 'Edit Member' : 'New Member'; ?></h3>
            <form method="post">
                <input type="hidden" name="old_no" value="<?= esc($edit['no_pelanggan'] ?? '') ?>">
                
                <div class="grid-inputs">
                    <div>
                        <label>Member ID</label>
                        <input
                            type="text"
                            value="<?= $edit ? esc($edit['no_pelanggan']) : 'Otomatis dari database' ?>"
                            readonly
                        >
                    </div>
                    <div>
                        <label>nama penuh</label>
                        <input type="text" name="nama" value="<?= esc($edit['nama'] ?? '') ?>" required>
                    </div>
                </div>

                <div class="grid-inputs">
                    <div>
                        <label>Ponsel</label>
                        <input type="text" name="no_hp" value="<?= $edit['no_hp'] ?? '' ?>" required>
                    </div>
                    <div>
                        <label>kelamin</label>
                        <select name="jenis_kelamin" required>
                            <option value="">Select</option>
                            <option value="laki_laki" <?= ($edit && $edit['jenis_kelamin']=='laki_laki') ? 'selected' : '' ?>>Male</option>
                            <option value="perempuan" <?= ($edit && $edit['jenis_kelamin']=='perempuan') ? 'selected' : '' ?>>Female</option>
                        </select>
                    </div>
                </div>

                <label>alamat</label>
                <textarea name="alamat" rows="2" required><?= $edit['alamat'] ?? '' ?></textarea>

                <button type="submit" class="btn">Update</button>
                <?php if ($edit): ?>
                    <a href="pelanggan.php" style="display:block; text-align:center; margin-top:15px; font-size:0.8rem; color:#fff; opacity:0.5; text-decoration:none;">Cancel</a>
                <?php endif; ?>
            </form>
        </div>

        <h3>Registered Customers</h3>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Info</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $n = 1;
                while ($r = mysqli_fetch_assoc($daftar_pelanggan)): 
                    $jk_label = ($r['jenis_kelamin']=='laki_laki') ? 'M' : 'F';
                ?>
                <tr>
                    <td><?= $n++ ?></td>
                    <td><?= $r['no_pelanggan'] ?></td>
                    <td>
                        <?= $r['nama'] ?> <small style="opacity:0.3">[<?= $jk_label ?>]</small>
                    </td>
                    <td>
                        <span style="opacity:0.7"><?= $r['no_hp'] ?></span><br>
                        <small style="opacity:0.4"><?= $r['alamat'] ?></small>
                    </td>
                    <td class="action-links">
                        <a href="?edit=<?= $r['no_pelanggan'] ?>" class="edit">Edit</a>
                        <a href="?delete=<?= $r['no_pelanggan'] ?>" class="delete" onclick="return confirm('Delete member?')">Remove</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <script type="importmap">
        {
            "imports": {
                "@splinetool/runtime": "https://unpkg.com/@splinetool/runtime@1.0.94/build/runtime.js"
            }
        }
    </script>
    <script type="module" src="../script.js"></script>
</body>
</html>
