<?php
include '../koneksi.php';
// Start session to check login status
session_start();

if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header('Location: ../index.php');
    exit;
}

function esc($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

if (isset($_GET['delete'])) {
    $id_game = (int) $_GET['delete'];
    if ($id_game > 0) {
        mysqli_query($mysqli, "DELETE FROM game WHERE id_game = '$id_game'");
    }
    header('Location: game.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_game = (int) ($_POST['id_game'] ?? 0);
    $old_id = (int) ($_POST['old_id'] ?? 0);
    $kategori = (int) ($_POST['kategori'] ?? 0);
    $nama_game = trim($_POST['nama_game'] ?? '');
    $jenis_game = trim($_POST['jenis_game'] ?? '');
    $jenis_ps = trim($_POST['jenis_ps'] ?? '');
    $nama_game = mysqli_real_escape_string($mysqli, $nama_game);
    $jenis_game = mysqli_real_escape_string($mysqli, $jenis_game);
    $jenis_ps = mysqli_real_escape_string($mysqli, $jenis_ps);

    $opsi_jenis_ps = array('Ps5', 'Ps4', 'Ps3', 'ps2');
    if (!in_array($jenis_ps, $opsi_jenis_ps, true)) {
        $jenis_ps = '';
    }

    if ($id_game > 0 && $kategori >= 0 && $nama_game !== '' && $jenis_game !== '' && $jenis_ps !== '') {
        if ($old_id > 0) {
            $query = "UPDATE game SET
                nama_game='$nama_game',
                id_game='$id_game',
                jenis_game='$jenis_game',
                kategori='$kategori',
                jenis_ps='$jenis_ps'
                WHERE id_game='$old_id'";
        } else {
            $query = "INSERT INTO game
                (nama_game, id_game, jenis_game, kategori, jenis_ps)
                VALUES
                ('$nama_game', '$id_game', '$jenis_game', '$kategori', '$jenis_ps')";
        }
        mysqli_query($mysqli, $query);
    }
    header('Location: game.php');
    exit;
}

$data_edit = null;
if (isset($_GET['edit'])) {
    $id_edit = (int) $_GET['edit'];

    if ($id_edit > 0) {
        $hasil = mysqli_query($mysqli, "SELECT * FROM game WHERE id_game='$id_edit'");
        $data_edit = mysqli_fetch_assoc($hasil);
    }
}

$daftar_game = mysqli_query($mysqli, "SELECT * FROM game ORDER BY id_game ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Game</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Outfit', sans-serif;
}
body {
    background: #000;
    color: #fff;
    padding: 20px;
    overflow-x: hidden;
}
#canvas3d {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: -1;
}
.container {
    max-width: 900px;
    margin: 0 auto;
    background: rgba(255, 255, 255, 0.03);
    backdrop-filter: blur(5px);
    border-radius: 12px;
    padding: 30px;
    border: 1px solid rgba(255, 255, 255, 0.1);
}
h1 {
    font-size: 1.8rem;
    font-weight: 600;
    margin-bottom: 30px;
    text-align: center;
    letter-spacing: 1px;
}
h3 {
    font-size: 1.1rem;
    font-weight: 400;
    margin-bottom: 20px;
    opacity: 0.8;
}
.form-section {
    margin-bottom: 40px;
    padding-bottom: 20px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}
.grid-inputs {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
}
label {
    display: block;
    font-size: 0.8rem;
    opacity: 0.6;
    margin-bottom: 5px;
}
input, select {
    width: 100%;
    background: transparent;
    border: none;
    border-bottom: 1px solid rgba(255, 255, 255, 0.2);
    padding: 10px 0;
    color: #fff;
    outline: none;
    transition: 0.3s;
    margin-bottom: 20px;
}
input:focus, select:focus {
    border-bottom-color: #fff;
}
option {
    background: #111;
    color: #fff;
}
.btn {
    background: #fff;
    color: #000;
    border: none;
    padding: 12px 25px;
    border-radius: 4px;
    font-weight: 600;
    cursor: pointer;
    transition: 0.3s;
    width: 100%;
    margin-top: 10px;
}
.btn:hover {
    background: #ccc;
    transform: translateY(-1px);
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}
th {
    text-align: left;
    font-size: 0.75rem;
    text-transform: uppercase;
    opacity: 0.5;
    padding: 15px 10px;
    font-weight: 400;
}
td {
    padding: 15px 10px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    font-size: 0.9rem;
}
.action-links a {
    text-decoration: none;
    font-size: 0.8rem;
    margin-right: 10px;
    transition: 0.3s;
}
.edit {
    color: #fff;
    opacity: 0.6;
}
.delete {
    color: #ff5555;
    opacity: 0.6;
}
.action-links a:hover {
    opacity: 1;
}
.nav {
    margin-bottom: 20px;
}
.nav a {
    color: #fff;
    text-decoration: none;
    font-size: 0.85rem;
    opacity: 0.5;
    transition: 0.3s;
}
.nav a:hover {
    opacity: 1;
}
    </style>
</head>
<body>
    <canvas id="canvas3d"></canvas>
    <div class="container">
        <div class="nav">
            <a href="../dashboard.php">kembali</a>
        </div>
        <h1>Data Game</h1>
        <div class="form-section">
            <h3><?php echo $data_edit ? 'Edit Game' : 'tambahkan game baru'; ?></h3>
            <form method="post">
                <input type="hidden" name="old_id" value="<?= esc($data_edit['id_game'] ?? '') ?>">
                <div class="grid-inputs">
                    <div>
                        <label>ID Game</label>
                        <input type="number" name="id_game" value="<?= esc($data_edit['id_game'] ?? '') ?>" required>
                    </div>
                    <div>
                        <label>Nama Game</label>
                        <input type="text" name="nama_game" value="<?= esc($data_edit['nama_game'] ?? '') ?>" required>
                    </div>
                </div>
                <div class="grid-inputs">
                    <div>
                        <label>Jenis Game</label>
                        <input type="text" name="jenis_game" value="<?= esc($data_edit['jenis_game'] ?? '') ?>" required>
                    </div>
                    <div>
                        <label>Kategori</label>
                        <input type="number" name="kategori" value="<?= esc($data_edit['kategori'] ?? '') ?>" required>
                    </div>
                </div>
                <div class="grid-inputs">
                    <div>
                        <label>Jenis PS</label>
                        <select name="jenis_ps" required>
                            <option value="">Pilih PS</option>
                            <option value="Ps5" <?= ($data_edit && $data_edit['jenis_ps'] === 'Ps5') ? 'selected' : '' ?>>PlayStation 5</option>
                            <option value="Ps4" <?= ($data_edit && $data_edit['jenis_ps'] === 'Ps4') ? 'selected' : '' ?>>PlayStation 4</option>
                            <option value="Ps3" <?= ($data_edit && $data_edit['jenis_ps'] === 'Ps3') ? 'selected' : '' ?>>PlayStation 3</option>
                            <option value="ps2" <?= ($data_edit && $data_edit['jenis_ps'] === 'ps2') ? 'selected' : '' ?>>PlayStation 2</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn">Simpan Game</button>
                <?php if ($data_edit): ?>
                    <a href="game.php" style="display:block; text-align:center; margin-top:15px; font-size:0.8rem; color:#fff; opacity:0.5; text-decoration:none;">Cancel</a>
                <?php endif; ?>
            </form>
        </div>
        <h3>Daftar Game</h3>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Jenis</th>
                    <th>Kategori</th>
                    <th>PS</th>
                    <th>aksi</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php
                $n = 1;
                while ($r = mysqli_fetch_assoc($daftar_game)):
                ?>
                <tr>
                    <td><?= $n++ ?></td>
                    <td><?= esc($r['id_game']) ?></td>
                    <td><?= esc($r['nama_game']) ?></td>
                    <td><?= esc($r['jenis_game']) ?></td>
                    <td><?= esc($r['kategori']) ?></td>
                    <td><?= esc($r['jenis_ps']) ?></td>
                    <td class="action-links">
                        <a href="?edit=<?= $r['id_game'] ?>" class="edit">Edit</a>
                        <a href="?delete=<?= $r['id_game'] ?>" class="delete" onclick="return confirm('Delete game?')">Remove</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <script type="importmap">
        {
            "imports": {
                "@splinetool/runtime": "https://unpkg.com/@splinetool/runtime@1.0.94/build/runtime.js"
            }
        }
    </script>
    <script type="module" src="../script.js"></script>
</body>
</html>
