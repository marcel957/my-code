<?php
include '../koneksi.php';
// Start session to check login status
session_start();

if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header('Location: ../index.php');
    exit;
}

if (isset($_GET['delete'])) {
    $delete = $_GET['delete'];
    mysqli_query($mysqli, "DELETE FROM rental WHERE no_transaksi = '$delete'");
    header('Location: rental.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $no_transaksi = $_POST['no_transaksi'];
    $jam_masuk    = $_POST['jam_masuk'];
    $jam_keluar   = $_POST['jam_keluar'];
    $harga_sewa   = $_POST['harga_sewa'];
    $id_karyawan  = $_POST['no_id'];
    $jenis_ps     = $_POST['jenis_ps'];
    $id_pelanggan = $_POST['no_pelanggan'];
    $id_game      = $_POST['id_game'];
    $old_no   = $_POST['old_no'] ?? '';

    if ($old_no != '') {
        $edit = "UPDATE rental SET
            no_transaksi='$no_transaksi', 
            jam_masuk='$jam_masuk',
            jam_keluar='$jam_keluar', 
            harga_sewa='$harga_sewa',
            no_id='$id_karyawan', 
            jenis_ps='$jenis_ps',
            no_pelanggan='$id_pelanggan', 
            id_game='$id_game'
            WHERE no_transaksi='$old_no'";
    } else {
        $edit = "INSERT INTO rental (no_transaksi, jam_masuk, jam_keluar, harga_sewa, no_id, jenis_ps, no_pelanggan, id_game)
            VALUES ('$no_transaksi','$jam_masuk','$jam_keluar','$harga_sewa','$id_karyawan','$jenis_ps','$id_pelanggan','$id_game')";
    }

    mysqli_query($mysqli, $edit);
    header('Location: rental.php');
    exit;
}

$data_edit = null;
if (isset($_GET['edit'])) {
    $hasil = mysqli_query($mysqli, "SELECT * FROM rental WHERE no_transaksi='{$_GET['edit']}'");
    $data_edit = mysqli_fetch_assoc($hasil);
}

$daftar_rental = mysqli_query($mysqli, "
    SELECT r.*, k.nama as nama_karyawan, p.nama as nama_pelanggan, g.nama_game
    FROM rental r
    LEFT JOIN karyawan k ON r.no_id=k.no_id
    LEFT JOIN pelanggan p ON r.no_pelanggan=p.no_pelanggan
    LEFT JOIN game g ON r.id_game=g.id_game
    ORDER BY r.no_transaksi Asc
");

$pilihan_karyawan = mysqli_query($mysqli, "SELECT no_id, nama FROM karyawan");
$pilihan_pelanggan = mysqli_query($mysqli, "SELECT no_pelanggan, nama FROM pelanggan");
$pilihan_game     = mysqli_query($mysqli, "SELECT id_game, nama_game FROM game");
?>

<!DOCTYPE html>
<html>
<head>
    <title> Data</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Outfit', sans-serif;
}
body {
    background: #000;
    color: #fff;
    padding: 20px;
    overflow-x: hidden;
}
#canvas3d {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: -1;
}
.container {
    max-width: 900px;
    margin: 0 auto;
    background: rgba(255, 255, 255, 0.03);
    backdrop-filter: blur(5px);
    border-radius: 12px;
    padding: 30px;
    border: 1px solid rgba(255, 255, 255, 0.1);
}
h1 {
    font-size: 1.8rem;
    font-weight: 600;
    margin-bottom: 30px;
    text-align: center;
    letter-spacing: 1px;
}
h3 {
    font-size: 1.1rem;
    font-weight: 400;
    margin-bottom: 20px;
    opacity: 0.8;
}
.form-section {
    margin-bottom: 40px;
    padding-bottom: 20px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}
.grid-inputs {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}
label {
    display: block;
    font-size: 0.8rem;
    opacity: 0.6;
    margin-bottom: 5px;
}
input, select {
    width: 100%;
    background: transparent;
    border: none;
    border-bottom: 1px solid rgba(255, 255, 255, 0.2);
    padding: 10px 0;
    color: #fff;
    outline: none;
    transition: 0.3s;
    margin-bottom: 20px;
}
input:focus, select:focus {
    border-bottom-color: #fff;
}
option {
    background: #111;
    color: #fff;
}
.btn {
    background: #fff;
    color: #000;
    border: none;
    padding: 12px 25px;
    border-radius: 4px;
    font-weight: 600;
    cursor: pointer;
    transition: 0.3s;
    width: 100%;
    margin-top: 10px;
}
.btn:hover {
    background: #ccc;
    transform: translateY(-1px);
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}
th {
    text-align: left;
    font-size: 0.75rem;
    text-transform: uppercase;
    opacity: 0.5;
    padding: 15px 10px;
    font-weight: 400;
}
td {
    padding: 15px 10px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    font-size: 0.9rem;
}
.action-links a {
    text-decoration: none;
    font-size: 0.8rem;
    margin-right: 10px;
    transition: 0.3s;
}
.edit {
    color: #fff;
    opacity: 0.6;
}
.delete {
    color: #ff5555;
    opacity: 0.6;
}
.action-links a:hover {
    opacity: 1;
}
.nav {
    margin-bottom: 20px;
}
.nav a {
    color: #fff;
    text-decoration: none;
    font-size: 0.85rem;
    opacity: 0.5;
    transition: 0.3s;
}
.nav a:hover {
    opacity: 1;
}

    </style>
</head>
<body>
    <canvas id="canvas3d"></canvas>

    <div class="container">
        <div class="nav">
            <a href="../dashboard.php">kembali</a>
        </div>
        <h1>Rental </h1>
        <div class="form-section">
            <h3><?php echo $data_edit ? 'Edit Record' : 'data baru'; ?></h3>
            <form method="post">
                <input type="hidden" name="old_no" value="<?= $data_edit['no_transaksi'] ?? '' ?>">
                
                <div class="grid-inputs">
                    <div>
                        <label>ID</label>
                        <input type="number" name="no_transaksi" value="<?= $data_edit['no_transaksi'] ?? '' ?>" required>
                    </div>
                    <div>
                        <label>harga (Rp)</label>
                        <input type="number" name="harga_sewa" value="<?= $data_edit['harga_sewa'] ?? '' ?>" required>
                    </div>
                </div>

                <div class="grid-inputs">
                    <div>
                        <label>waktu masuk</label>
                        <input type="datetime-local" name="jam_masuk" value="<?= isset($data_edit['jam_masuk']) ? date('Y-m-d\TH:i', strtotime($data_edit['jam_masuk'])) : '' ?>" required>
                    </div>
                    <div>
                        <label>waktu keluar</label>
                        <input type="datetime-local" name="jam_keluar" value="<?= isset($data_edit['jam_keluar']) ? date('Y-m-d\TH:i', strtotime($data_edit['jam_keluar'])) : '' ?>" required>
                    </div>
                </div>

                <div class="grid-inputs">
                    <div>
                        <label>Karyawan</label>
                        <select name="no_id" required>
                            <option value="">Select Staff</option>
                            <?php while ($k = mysqli_fetch_assoc($pilihan_karyawan)): ?>
                                <option value="<?= $k['no_id'] ?>" <?= ($data_edit && $data_edit['no_id']==$k['no_id']) ? 'selected' : '' ?>><?= $k['nama'] ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div>
                        <label>PS Type</label>
                        <select name="jenis_ps" required>
                            <option value="">Select PS</option>
                            <option value="Ps5" <?= ($data_edit && $data_edit['jenis_ps']=='Ps5') ? 'selected' : '' ?>>PlayStation 5</option>
                            <option value="Ps4" <?= ($data_edit && $data_edit['jenis_ps']=='Ps4') ? 'selected' : '' ?>>PlayStation 4</option>
                            <option value="Ps3" <?= ($data_edit && $data_edit['jenis_ps']=='Ps3') ? 'selected' : '' ?>>PlayStation 3</option>
                            <option value="Ps2" <?= ($data_edit && $data_edit['jenis_ps']=='Ps2') ? 'selected' : '' ?>>PlayStation 2</option>
                        </select>
                    </div>
                </div>

                <div class="grid-inputs">
                    <div>
                        <label>pelanggan</label>
                        <select name="no_pelanggan" required>
                            <option value="">pilih pelanggan</option>
                            <?php while ($p = mysqli_fetch_assoc($pilihan_pelanggan)): ?>
                                <option value="<?= $p['no_pelanggan'] ?>" <?= ($data_edit && $data_edit['no_pelanggan']==$p['no_pelanggan']) ? 'selected' : '' ?>><?= $p['nama'] ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div>
                        <label>Game</label>
                        <select name="id_game" required>
                            <option value="">Select Game</option>
                            <?php while ($g = mysqli_fetch_assoc($pilihan_game)): ?>
                                <option value="<?= $g['id_game'] ?>" <?= ($data_edit && $data_edit['id_game']==$g['id_game']) ? 'selected' : '' ?>><?= $g['nama_game'] ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                <button type="submit" class="btn">konfirmasi</button>
                <?php if ($data_edit): ?>
                    <a href="rental.php" style="display:block; text-align:center; margin-top:15px; font-size:0.8rem; color:#fff; opacity:0.5; text-decoration:none;">Cancel</a>
                <?php endif; ?>
            </form>
        </div>

        <h3>Recent Activity</h3>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Time</th>
                    <th>Price</th>
                    <th>PS</th>
                    <th>Info</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $n = 1;
                while ($r = mysqli_fetch_assoc($daftar_rental)): 
                ?>
                <tr>
                    <td><?= $n++ ?></td>
                    <td>
                        <?= date('H:i', strtotime($r['jam_masuk'])) ?> - <?= date('H:i', strtotime($r['jam_keluar'])) ?>
                    </td>
                    <td>Rp <?= number_format($r['harga_sewa'], 0, ',', '.') ?></td>
                    <td><?= $r['jenis_ps'] ?></td>
                    <td>
                        <span style="opacity:0.7"><?= $r['nama_pelanggan'] ?></span><br>
                        <small style="opacity:0.4"><?= $r['nama_game'] ?></small>
                    </td>
                    <td class="action-links">
                        <a href="?edit=<?= $r['no_transaksi'] ?>" class="edit">Edit</a>
                        <a href="?delete=<?= $r['no_transaksi'] ?>" class="delete" onclick="return confirm('Delete record?')">Remove</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <script type="importmap">
        {
            "imports": {
                "@splinetool/runtime": "https://unpkg.com/@splinetool/runtime@1.0.94/build/runtime.js"
            }
        }
    </script>
    <script type="module" src="../script.js"></script>
</body>
</html>
