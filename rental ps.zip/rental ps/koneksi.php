<?php
$databaseHost = 'localhost';
$databaseName = 'db_rentalps';
$databaseUsername = 'root';
$databasePassword = '';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);
?>