<?php
include 'koneksi.php';
// Start session to check login status
session_start();

// Simple check if user is logged in
if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

$username = $_SESSION['username'] ?? 'User';

function esc($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$q_total_unit = mysqli_query($mysqli, "SELECT COUNT(*) AS total FROM game");
$total_unit = (int) (mysqli_fetch_assoc($q_total_unit)['total'] ?? 0);
$q_disewa = mysqli_query($mysqli, "SELECT COUNT(*) AS total FROM rental WHERE jam_keluar > NOW()");
$sedang_disewa = (int) (mysqli_fetch_assoc($q_disewa)['total'] ?? 0);
$q_member = mysqli_query($mysqli, "SELECT COUNT(*) AS total FROM pelanggan");
$member_aktif = (int) (mysqli_fetch_assoc($q_member)['total'] ?? 0);

$latest_rental = mysqli_query(
    $mysqli,
    "SELECT 
        r.no_transaksi,
        r.jam_masuk,
        r.jam_keluar,
        r.harga_sewa,
        r.jenis_ps,
        p.nama AS nama_pelanggan,
        k.nama AS nama_karyawan,
        g.nama_game
    FROM rental r
    INNER JOIN pelanggan p ON r.no_pelanggan = p.no_pelanggan
    INNER JOIN karyawan k ON r.no_id = k.no_id
    INNER JOIN game g ON r.id_game = g.id_game
    ORDER BY r.jam_masuk Asc
    LIMIT 8"
);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Rental PS</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #ffffffff;
            --text-main: #fff;
            --text-dim: #ccc;
            --accent: #ffffffff;
            --sidebar-width: 260px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Outfit', sans-serif;
        }

        body {
            background-color: #000;
            color: var(--text-main);
            overflow: hidden;
            height: 100vh;
        }

        /* 3D Canvas Background */
        #canvas3d {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
        }

        .main-container {
            display: flex;
            height: 100vh;
            background: transparent;
        }

        /* Sidebar */
        aside {
            width: var(--sidebar-width);
            background: transparent;
            border: none;
            display: flex;
            flex-direction: column;
            padding: 24px;
            z-index: 10;
        }

        .logo {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 48px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: var(--primary);
            text-shadow: 0 0 10px rgba(168, 85, 247, 0.4);
        }

        .nav-links {
            list-style: none;
            flex: 1;
        }

        .nav-links li {
            margin-bottom: 8px;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--text-dim);
            padding: 12px 16px;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.2s ease;
        }

        .nav-links a:hover, .nav-links a.active {
            color: var(--text-main);
            background: transparent;
        }

        .nav-links a.active {
            font-weight: 700;
            color: var(--primary);
        }

        .btn-logout {
            margin-top: auto;
            text-decoration: none;
            color: var(--accent);
            padding: 10px 16px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
            background: transparent;
            border: 1px solid var(--accent);
            transition: all 0.3s ease;
            font-weight: 600;
        }

        .btn-logout:hover {
            color: #fff;
            border-color: #fff;
            box-shadow: 0 0 10px #fff;
        }

        /* Main Content */
        main {
            flex: 1;
            padding: 40px;
            overflow-y: auto;
            z-index: 1;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
        }

        .welcome-text h1 {
            font-size: 32px;
            margin-bottom: 4px;
            font-weight: 700;
        }

        .welcome-text p {
            color: var(--text-dim);
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 24px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: transparent;
            padding: 24px;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: scale(1.02);
            background: transparent;
            border-color: transparent;
        }

        .stat-card h3 {
            font-size: 13px;
            color: var(--text-dim);
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 600;
        }

        .stat-card .value {
            font-size: 36px;
            font-weight: 700;
            color: #fff;
        }

        .content-card {
            background: transparent;
            padding: 32px;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }

        .btn-primary {
            background: transparent;
            color: var(--primary);
            border: 1px solid var(--primary);
            padding: 10px 20px;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            color: #fff;
            border-color: #fff;
            box-shadow: 0 0 10px #fff;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            color: var(--text-dim);
            font-size: 13px;
            padding: 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            text-transform: uppercase;
        }

        td {
            padding: 16px 12px;
            font-size: 15px;
            border-bottom: none;
        }

        .placeholder-row {
            color: var(--text-dim);
            font-style: italic;
            text-align: center;
            padding: 60px !important;
        }

        /* Scrollbar Styling */
        main::-webkit-scrollbar {
            width: 4px;
        }
        main::-webkit-scrollbar-track {
            background: transparent;
        }
        main::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.2);
            border-radius: 10px;
        }

        @media (max-width: 768px) {
            aside {
                display: none;
            }
            main {
                padding: 24px;
            }
        }
    </style>


</head>
<body>
    <canvas id="canvas3d"></canvas>

    <div class="main-container">
        <aside>
            <div class="logo">
                <span>🎮</span> Rental PS
            </div>
            <ul class="nav-links">
                <li><a href="dashboard.php" class="active"><span>🏠</span> Dashboard</a></li>
                <li><a href="data/pelanggan.php"><span>👤</span> Pelanggan</a></li>
                <li><a href="data/rental.php"><span>⏱️</span> Rental</a></li>
                <li><a href="data/karyawan.php"><span>👤</span> Karyawan</a></li>
                <li><a href="data/game.php"><span>🎮</span> Game</a></li>
            </ul>
            <a href="index.php?logout" class="btn-logout"><span>Logout</span> 🔒</a>
        </aside>

        <main>
            <header>
                <div class="welcome-text">
                    <h1>Halo, <?php echo htmlspecialchars($username); ?>! 👋</h1>
                    <p>Selamat datang kembali di sistem Rental PlayStation.</p>
                </div>
            </header>

            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Unit</h3>
                    <div class="value"><?= esc($total_unit) ?></div>
                </div>
                <div class="stat-card">
                    <h3>Sedang Disewa</h3>
                    <div class="value"><?= esc($sedang_disewa) ?></div>
                </div>
                <div class="stat-card">
                    <h3>Member Aktif</h3>
                    <div class="value"><?= esc($member_aktif) ?></div>
                </div>
            </div>

            <div class="content-card">
                <div class="card-header">
                    <h2>Data Penyewaan Terbaru</h2>
                    <a href="data/rental.php" class="btn-primary">+ Tambah Data</a>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Unit PS</th>
                            <th>Nama Penyewa</th>
                            <th>Mulai</th>
                            <th>Durasi</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$latest_rental || mysqli_num_rows($latest_rental) === 0): ?>
                            <tr>
                                <td colspan="5" class="placeholder-row">
                                    Belum ada data penyewaan saat ini. Klik tombol di atas untuk menambah data.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php while ($r = mysqli_fetch_assoc($latest_rental)): ?>
                                <?php
                                    $mulai = date('d/m/Y H:i', strtotime($r['jam_masuk']));
                                    $durasi_jam = max(0, (strtotime($r['jam_keluar']) - strtotime($r['jam_masuk'])) / 3600);
                                    $durasi_label = rtrim(rtrim(number_format($durasi_jam, 2, '.', ''), '0'), '.') . ' jam';
                                    $status = (strtotime($r['jam_keluar']) > time()) ? 'Aktif' : 'Selesai';
                                ?>
                                <tr>
                                    <td><?= esc($r['jenis_ps']) ?> — <?= esc($r['nama_game']) ?></td>
                                    <td><?= esc($r['nama_pelanggan']) ?></td>
                                    <td><?= esc($mulai) ?></td>
                                    <td><?= esc($durasi_label) ?></td>
                                    <td><?= esc($status) ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>

    <script type="importmap">
        {
            "imports": {
                "@splinetool/runtime": "https://unpkg.com/@splinetool/runtime@1.0.94/build/runtime.js"
            }
        }
    </script>
    <script type="module" src="script.js"></script>
</body>
</html>
