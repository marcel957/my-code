<?php
require_once __DIR__ . '/inc/app.php';
login('index.php');
allow(['petugas'], 'tampilan.php');

$masuk = (int)val("SELECT COUNT(*) FROM tb_transaksi WHERE status='masuk' AND DATE(waktu_masuk)=CURDATE()");
$keluar = (int)val("SELECT COUNT(*) FROM tb_transaksi WHERE status='keluar' AND DATE(waktu_keluar)=CURDATE()");
$berjalan = (int)val("SELECT COUNT(*) FROM tb_transaksi WHERE status='masuk'");
$income = (float)val("SELECT COALESCE(SUM(biaya_total),0) FROM tb_transaksi WHERE status='keluar' AND DATE(waktu_keluar)=CURDATE()");

$antrian = mysqli_query($mysqli, "SELECT t.id_parkir, t.waktu_masuk, k.plat_nomor, k.jenis_kendaraan, a.nama_area FROM tb_transaksi t LEFT JOIN tb_kendaraan k ON t.id_kendaraan=k.Id_kendaraaan LEFT JOIN tb_area_parkir a ON t.id_area=a.id_area WHERE t.status='masuk' ORDER BY t.waktu_masuk DESC LIMIT 5");
$riwayat = mysqli_query($mysqli, "SELECT t.id_parkir, t.waktu_keluar, k.plat_nomor, tr.jenis_kendaraan, t.biaya_total FROM tb_transaksi t LEFT JOIN tb_kendaraan k ON t.id_kendaraan=k.Id_kendaraaan LEFT JOIN tb_tarif tr ON t.id_tarif=tr.id_tarif WHERE t.status='keluar' ORDER BY t.waktu_keluar DESC LIMIT 5");

$title = 'Dashboard';
$active = 'dashboard';
$base = '';
include __DIR__ . '/inc/header.php';
?>

<div class="grid grid-4">
    <div class="stat-card stat-blue"><div class="label">Masuk Hari Ini</div><div class="big"><?php echo h($masuk); ?></div><span class="stat-icon"><i class="bi bi-box-arrow-in-down"></i></span></div>
    <div class="stat-card stat-green"><div class="label">Keluar Hari Ini</div><div class="big"><?php echo h($keluar); ?></div><span class="stat-icon"><i class="bi bi-box-arrow-up"></i></span></div>
    <div class="stat-card stat-orange"><div class="label">Transaksi Berjalan</div><div class="big"><?php echo h($berjalan); ?></div><span class="stat-icon"><i class="bi bi-hourglass-split"></i></span></div>
    <div class="stat-card stat-purple"><div class="label">Pendapatan Hari Ini</div><div class="big"><?php echo h(rupiah($income)); ?></div><span class="stat-icon"><i class="bi bi-currency-dollar"></i></span></div>
</div>

<div class="grid grid-2">
    <div class="card">
        <div class="section-title">Antrian Kendaraan Masuk</div>
        <div class="table-wrap">
            <table class="table">
                <thead><tr><th>ID</th><th>Plat</th><th>Jenis</th><th>Area</th></tr></thead>
                <tbody>
                    <?php if ($antrian && mysqli_num_rows($antrian) > 0): while ($row = mysqli_fetch_assoc($antrian)): ?>
                        <tr><td><?php echo h($row['id_parkir']); ?></td><td><?php echo h($row['plat_nomor'] ?: '-'); ?></td><td><?php echo h($row['jenis_kendaraan'] ?: '-'); ?></td><td><?php echo h($row['nama_area'] ?: '-'); ?></td></tr>
                    <?php endwhile; else: ?><tr><td colspan="4">Belum ada kendaraan masuk.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="actions"><a class="btn primary" href="data/transaksi.php">Kelola</a></div>
    </div>
    <div class="card">
        <div class="section-title">Transaksi Keluar</div>
        <div class="table-wrap">
            <table class="table">
                <thead><tr><th>ID</th><th>Plat</th><th>Jenis</th><th>Total</th></tr></thead>
                <tbody>
                    <?php if ($riwayat && mysqli_num_rows($riwayat) > 0): while ($row = mysqli_fetch_assoc($riwayat)): ?>
                        <tr><td><?php echo h($row['id_parkir']); ?></td><td><?php echo h($row['plat_nomor'] ?: '-'); ?></td><td><?php echo h($row['jenis_kendaraan'] ?: '-'); ?></td><td><?php echo h(rupiah($row['biaya_total'])); ?></td></tr>
                    <?php endwhile; else: ?><tr><td colspan="4">Belum ada transaksi keluar.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="actions"><a class="btn primary" href="data/transaksi.php">Lihat Transaksi</a></div>
    </div>
</div>

<?php render_footer(); ?>