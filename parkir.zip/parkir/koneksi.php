<?php
$databaseHost = 'localhost';
$databaseName = 'db_parkir';
$databaseUsername = 'root';
$databasePassword = '';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);
if($mysqli == TRUE){
    // echo "berhasil terhubung";
}else{
    echo "gagal terhubung";
}
?>         