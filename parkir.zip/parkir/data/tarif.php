<?php
require_once __DIR__ . '/../inc/app.php';
login('../index.php');
allow(['admin'], '../tampilan.php');

// SIMPAN TARIF (TAMBAH ATAU UBAH)
if (isset($_POST['simpan'])) {
    $jenis = $_POST['jenis_kendaraan'];
    $tarif = $_POST['tarif_per_jam'];
    $detail = $jenis . ' - Rp ' . $tarif;
    
    if (isset($_POST['id'])) {
        // UBAH DATA YANG SUDAH ADA
        $id = (int)$_POST['id'];
        mysqli_query($mysqli, "UPDATE tb_tarif SET jenis_kendaraan='$jenis', tarif_per_jam='$tarif' WHERE id_tarif=$id");
        log_aktivitas(user_id(), "UBAH Tarif - $detail");
    } else {
        // TAMBAH TARIF BARU
        mysqli_query($mysqli, "INSERT INTO tb_tarif (jenis_kendaraan, tarif_per_jam) VALUES ('$jenis', '$tarif')");
        log_aktivitas(user_id(), "TAMBAH Tarif - $detail");
    }
    go('tarif.php');
}

// HAPUS TARIF
if (isset($_GET['del'])) {
    $id = (int)$_GET['del'];
    mysqli_query($mysqli, "DELETE FROM tb_tarif WHERE id_tarif=$id");
    log_aktivitas(user_id(), "HAPUS Tarif - ID $id");
    go('tarif.php');
}

// AMBIL DATA UNTUK EDIT
$edit = null;
if (isset($_GET['edit'])) {
    $r = mysqli_query($mysqli, "SELECT * FROM tb_tarif WHERE id_tarif=" . (int)$_GET['edit']);
    $edit = mysqli_fetch_assoc($r);
}

// AMBIL DATA TARIF DARI DATABASE
$data = mysqli_query($mysqli, "SELECT * FROM tb_tarif LIMIT 200");
$title = 'Tarif Parkir';
$active = 'tarif';
$base = '../';
include __DIR__ . '/../inc/header.php';
?>

<div class="page-header">
    <h1 class="page-title"><span class="title-icon"><i class="bi bi-receipt"></i></span> Tarif Parkir</h1>
    <div class="page-toolbar">
        <div class="search-wrap"><span class="search-icon"><i class="bi bi-search"></i></span><input type="text" placeholder="Cari..." id="searchTarif"></div>
        <button type="button" class="icon-btn" title="Pengaturan"><i class="bi bi-gear"></i></button>
        <button type="button" class="icon-btn" title="Daftar"><i class="bi bi-list-ul"></i></button>
        <a href="tarif.php" class="btn primary"><i class="bi bi-plus-lg"></i> Tambah Tarif</a>
    </div>
</div>

<div class="grid grid-2">
    <div class="card">
        <div class="label"><?php echo isset($_GET['edit']) ? 'Edit Tarif' : 'Tambah Tarif'; ?></div>
        <form method="POST" class="form">
            <?php if (isset($_GET['edit'])): ?><input type="hidden" name="id" value="<?php echo $edit['id_tarif']; ?>"><?php endif; ?>
            <div class="form-grid">
                <div><label>Jenis Kendaraan</label>
                    <select name="jenis_kendaraan" required>
                        <option value="">Pilih</option>
                        <option value="mobil" <?php echo (isset($edit) && $edit['jenis_kendaraan'] == 'mobil') ? 'selected' : ''; ?>>Mobil</option>
                        <option value="motor" <?php echo (isset($edit) && $edit['jenis_kendaraan'] == 'motor') ? 'selected' : ''; ?>>Motor</option>
                        <option value="lainnya" <?php echo (isset($edit) && $edit['jenis_kendaraan'] == 'lainnya') ? 'selected' : ''; ?>>Lainnya</option>
                    </select>
                </div>
                <div><label>Tarif per Jam</label><input type="number" step="0.01" name="tarif_per_jam" value="<?php echo isset($edit) ? $edit['tarif_per_jam'] : ''; ?>" required></div>
            </div>
            <div class="actions">
                <button class="btn" type="submit" name="simpan">Simpan</button>
                <button class="btn secondary" type="reset">Reset</button>
                <?php if (isset($_GET['edit'])): ?><a class="btn secondary" href="tarif.php">Batal</a><?php endif; ?>
            </div>
        </form>
    </div>
    <div class="card">
        <div class="label">Data Tarif</div>
        <div class="table-wrap">
        <table class="table">
            <thead><tr><th>Jenis Kendaraan</th><th>Tarif Per Jam</th><th>Aksi</th></tr></thead>
            <tbody>
                <?php if ($data && mysqli_num_rows($data) > 0): while ($row = mysqli_fetch_assoc($data)): ?>
                    <tr>
                        <td><?php echo h(ucfirst($row['jenis_kendaraan'])); ?></td>
                        <td><?php echo h(rupiah($row['tarif_per_jam'])); ?></td>
                        <td>
                            <div class="table-actions">
                                <a class="btn-icon" href="tarif.php?edit=<?php echo $row['id_tarif']; ?>" title="Edit"><i class="bi bi-pencil"></i></a>
                                <a class="btn-icon danger" href="tarif.php?del=<?php echo $row['id_tarif']; ?>" onclick="return confirm('Hapus?')" title="Hapus"><i class="bi bi-trash"></i></a>
                            </div>
                        </td>
                    </tr>
                <?php endwhile; else: ?>
                    <tr><td colspan="3">Data tarif belum tersedia.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>

<?php render_footer(); ?>
