<?php
require_once __DIR__ . '/../inc/app.php';
login('../index.php');
allow(['admin'], '../tampilan.php');

if (isset($_POST['simpan'])) {
    $plat = mysqli_real_escape_string($mysqli, $_POST['plat_nomor']);
    $jenis = mysqli_real_escape_string($mysqli, $_POST['jenis_kendaraan']);
    $warna = mysqli_real_escape_string($mysqli, $_POST['warna']);
    $pemilik = mysqli_real_escape_string($mysqli, $_POST['pemilik']);
    $id_user = mysqli_real_escape_string($mysqli, $_POST['id_user']);
    $detail = "$plat - $pemilik (" . ucfirst($jenis) . ")";
    if (isset($_POST['id'])) {
        $id = (int)$_POST['id'];
        mysqli_query($mysqli, "UPDATE tb_kendaraan SET plat_nomor='$plat', jenis_kendaraan='$jenis', warna='$warna', pemilik='$pemilik', id_user='$id_user' WHERE Id_kendaraaan=$id");
        log_aktivitas(user_id(), "UBAH Kendaraan - $detail");
    } else {
        mysqli_query($mysqli, "INSERT INTO tb_kendaraan (plat_nomor, jenis_kendaraan, warna, pemilik, id_user) VALUES ('$plat', '$jenis', '$warna', '$pemilik', '$id_user')");
        log_aktivitas(user_id(), "TAMBAH Kendaraan - $detail");
    }
    go('kendaraan.php');
}

if (isset($_GET['del'])) {
    $id = (int)$_GET['del'];
    $r = mysqli_fetch_assoc(mysqli_query($mysqli, "SELECT plat_nomor, pemilik FROM tb_kendaraan WHERE Id_kendaraaan=$id LIMIT 1"));
    $detail = $r ? $r['plat_nomor'] . ' - ' . $r['pemilik'] : "ID $id";
    log_aktivitas(user_id(), "HAPUS Kendaraan - $detail");
    mysqli_query($mysqli, "DELETE FROM tb_kendaraan WHERE Id_kendaraaan=$id");
    go('kendaraan.php');
}

$edit = null;
if (isset($_GET['edit'])) {
    $r = mysqli_query($mysqli, "SELECT * FROM tb_kendaraan WHERE Id_kendaraaan=" . (int)$_GET['edit']);
    $edit = mysqli_fetch_assoc($r);
}

$users = mysqli_query($mysqli, "SELECT id_user, nama_lengkap, username FROM tb_user ORDER BY nama_lengkap");
$jenis_ops = [];
$jr = mysqli_query($mysqli, "SELECT DISTINCT jenis_kendaraan FROM tb_tarif ORDER BY jenis_kendaraan");
if ($jr) while ($j = mysqli_fetch_assoc($jr)) { if (!empty($j['jenis_kendaraan'])) $jenis_ops[] = $j['jenis_kendaraan']; }
if (count($jenis_ops) === 0) $jenis_ops = ['mobil', 'motor', 'lainnya'];

$data = mysqli_query($mysqli, "SELECT k.*, u.nama_lengkap, u.username FROM tb_kendaraan k LEFT JOIN tb_user u ON k.id_user = u.id_user LIMIT 200");
$title = 'Data Kendaraan';
$active = 'kendaraan';
$base = '../';
include __DIR__ . '/../inc/header.php';
?>

<div class="page-header">
    <h1 class="page-title"><span class="title-icon"><i class="bi bi-car-front-fill"></i></span> Data Kendaraan</h1>
    <div class="page-toolbar">
        <div class="search-wrap"><span class="search-icon"><i class="bi bi-search"></i></span><input type="text" placeholder="Cari..." id="searchKendaraan"></div>
        <button type="button" class="icon-btn" title="Pengaturan"><i class="bi bi-gear"></i></button>
        <button type="button" class="icon-btn" title="Daftar"><i class="bi bi-list-ul"></i></button>
        <a href="kendaraan.php" class="btn primary"><i class="bi bi-plus-lg"></i> Tambah Kendaraan</a>
    </div>
</div>

<div class="grid grid-2">
    <div class="card">
        <div class="label"><?php echo isset($_GET['edit']) ? 'Edit Kendaraan' : 'Tambah Kendaraan'; ?></div>
        <form method="POST" class="form">
            <?php if (isset($_GET['edit'])): ?><input type="hidden" name="id" value="<?php echo $edit['Id_kendaraaan']; ?>"><?php endif; ?>
            <div class="form-grid">
                <div><label>Plat Nomor</label><input type="text" name="plat_nomor" value="<?php echo isset($edit) ? h($edit['plat_nomor']) : ''; ?>" required></div>
                <div><label>Jenis Kendaraan</label>
                    <select name="jenis_kendaraan" required>
                        <option value="">Pilih</option>
                        <?php foreach ($jenis_ops as $jenis): ?>
                            <option value="<?php echo $jenis; ?>" <?php echo (isset($edit) && $edit['jenis_kendaraan'] == $jenis) ? 'selected' : ''; ?>><?php echo ucfirst($jenis); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div><label>Warna</label><input type="text" name="warna" value="<?php echo isset($edit) ? h($edit['warna']) : ''; ?>" required></div>
                <div><label>Pemilik</label><input type="text" name="pemilik" value="<?php echo isset($edit) ? h($edit['pemilik']) : ''; ?>" required></div>
                <div><label>User</label>
                    <select name="id_user" required>
                        <option value="">Pilih</option>
                        <?php while ($u = mysqli_fetch_assoc($users)): ?>
                            <option value="<?php echo $u['id_user']; ?>" <?php echo (isset($edit) && $edit['id_user'] == $u['id_user']) ? 'selected' : ''; ?>><?php echo $u['nama_lengkap'] . ' (' . $u['username'] . ')'; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
            </div>
            <div class="actions">
                <button class="btn" type="submit" name="simpan">Simpan</button>
                <button class="btn secondary" type="reset">Reset</button>
                <?php if (isset($_GET['edit'])): ?><a class="btn secondary" href="kendaraan.php">Batal</a><?php endif; ?>
            </div>
        </form>
    </div>
    <div class="card">
        <div class="label">Data Kendaraan</div>
        <div class="table-wrap">
        <table class="table">
            <thead><tr><th>No.</th><th>Nomor Polisi</th><th>Jenis</th><th>Warna</th><th>Status</th><th>Aksi</th></tr></thead>
            <tbody>
                <?php $no = 1; if ($data && mysqli_num_rows($data) > 0): while ($row = mysqli_fetch_assoc($data)): ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo h($row['plat_nomor']); ?></td>
                        <td><?php echo h(ucfirst($row['jenis_kendaraan'])); ?></td>
                        <td><?php echo h($row['warna']); ?></td>
                        <td><?php echo h($row['nama_lengkap'] ? 'Aktif' : '-'); ?></td>
                        <td>
                            <div class="table-actions">
                                <a class="btn-icon" href="kendaraan.php?edit=<?php echo $row['Id_kendaraaan']; ?>" title="Edit"><i class="bi bi-pencil"></i></a>
                                <a class="btn-icon danger" href="kendaraan.php?del=<?php echo $row['Id_kendaraaan']; ?>" onclick="return confirm('Hapus?')" title="Hapus"><i class="bi bi-trash"></i></a>
                            </div>
                        </td>
                    </tr>
                <?php endwhile; else: ?>
                    <tr><td colspan="6">Data kendaraan belum tersedia.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>

<?php render_footer(); ?>
