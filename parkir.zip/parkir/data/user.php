<?php
require_once __DIR__ . '/../inc/app.php';
login('../index.php');
allow(['admin'], '../tampilan.php');

if (isset($_POST['simpan'])) {
    $nama = $_POST['nama'];
    $user = $_POST['user'];
    $pass = $_POST['pass'];
    $role = $_POST['role'];
    $status = $_POST['status'];
    $detail = "$nama ($user)";
    
    if (isset($_POST['id'])) {
        $id = (int)$_POST['id'];
        mysqli_query($mysqli, "UPDATE tb_user SET nama_lengkap='$nama', username='$user', password='$pass', role='$role', status_aktif='$status' WHERE id_user=$id");
        log_aktivitas(user_id(), "UBAH User - $detail");
    } else {
        mysqli_query($mysqli, "INSERT INTO tb_user (nama_lengkap, username, password, role, status_aktif) VALUES ('$nama', '$user', '$pass', '$role', '$status')");
        log_aktivitas(user_id(), "TAMBAH User - $detail");
    }
    go('user.php');
}

if (isset($_GET['del'])) {
    $id = (int)$_GET['del'];
    mysqli_query($mysqli, "DELETE FROM tb_user WHERE id_user=$id");
    log_aktivitas(user_id(), "HAPUS User - ID $id");
    go('user.php');
}

$edit_user = null;
if (isset($_GET['edit'])) {
    $r = mysqli_query($mysqli, "SELECT * FROM tb_user WHERE id_user=" . (int)$_GET['edit']);
    $edit_user = mysqli_fetch_assoc($r);
}

$data_user = mysqli_query($mysqli, "SELECT * FROM tb_user LIMIT 200");
$is_edit = isset($_GET['edit']);
$title = 'User';
$active = 'user';
$base = '../';
include __DIR__ . '/../inc/header.php';
?>

<div class="page-header">
    <h1 class="page-title"><span class="title-icon"><i class="bi bi-person"></i></span> User</h1>
    <div class="page-toolbar">
        <div class="search-wrap"><span class="search-icon"><i class="bi bi-search"></i></span><input type="text" placeholder="Cari..." id="searchUser"></div>
        <button type="button" class="icon-btn" title="Pengaturan"><i class="bi bi-gear"></i></button>
        <button type="button" class="icon-btn" title="Daftar"><i class="bi bi-list-ul"></i></button>
        <a href="user.php" class="btn primary"><i class="bi bi-plus-lg"></i> Tambah User</a>
    </div>
</div>

<div class="grid grid-2">
    <div class="card">
        <div class="label"><?php echo $is_edit ? 'Edit User' : 'Tambah User'; ?></div>
        <form method="POST" class="form">
            <?php if ($is_edit): ?><input type="hidden" name="id" value="<?php echo $edit_user['id_user']; ?>"><?php endif; ?>
            <div class="form-grid">
                <div><label>Nama</label><input type="text" name="nama" value="<?php echo isset($edit_user) ? h($edit_user['nama_lengkap']) : ''; ?>" required></div>
                <div><label>Username</label><input type="text" name="user" value="<?php echo isset($edit_user) ? h($edit_user['username']) : ''; ?>" required></div>
                <div><label>Password</label><input type="text" name="pass" value="<?php echo isset($edit_user) ? h($edit_user['password']) : ''; ?>" required></div>
                <div><label>Role</label>
                    <select name="role" required>
                        <option value="">Pilih</option>
                        <option value="admin" <?php echo (isset($edit_user) && $edit_user['role'] == 'admin') ? 'selected' : ''; ?>>Admin</option>
                        <option value="petugas" <?php echo (isset($edit_user) && $edit_user['role'] == 'petugas') ? 'selected' : ''; ?>>Petugas</option>
                        <option value="owner" <?php echo (isset($edit_user) && $edit_user['role'] == 'owner') ? 'selected' : ''; ?>>Owner</option>
                    </select>
                </div>
                <div><label>Status</label>
                    <select name="status" required>
                        <option value="">Pilih</option>
                        <option value="1" <?php echo (isset($edit_user) && $edit_user['status_aktif'] == '1') ? 'selected' : ''; ?>>Aktif</option>
                        <option value="0" <?php echo (isset($edit_user) && $edit_user['status_aktif'] == '0') ? 'selected' : ''; ?>>Tidak</option>
                    </select>
                </div>
            </div>
            <div class="actions">
                <button class="btn" type="submit" name="simpan">Simpan</button>
                <button class="btn secondary" type="reset">Reset</button>
                <?php if ($is_edit): ?><a class="btn secondary" href="user.php">Batal</a><?php endif; ?>
            </div>
        </form>
    </div>
    <div class="card">
        <div class="label">Data User</div>
        <table class="table">
            <thead><tr><th>ID</th><th>Nama</th><th>User</th><th>Role</th><th>Status</th><th>Aksi</th></tr></thead>
            <tbody>
                <?php if ($data_user && mysqli_num_rows($data_user) > 0): while ($row = mysqli_fetch_assoc($data_user)): ?>
                    <tr>
                        <td><?php echo h($row['id_user']); ?></td>
                        <td><?php echo h($row['nama_lengkap']); ?></td>
                        <td><?php echo h($row['username']); ?></td>
                        <td><?php echo h($row['role']); ?></td>
                        <td><?php echo $row['status_aktif'] == 1 ? 'Aktif' : 'Tidak'; ?></td>
                        <td>
                            <div class="table-actions">
                                <a class="btn-icon" href="user.php?edit=<?php echo $row['id_user']; ?>" title="Edit"><i class="bi bi-pencil"></i></a>
                                <a class="btn-icon danger" href="user.php?del=<?php echo $row['id_user']; ?>" onclick="return confirm('Hapus?')" title="Hapus"><i class="bi bi-trash"></i></a>
                            </div>
                        </td>
                    </tr>
                <?php endwhile; else: ?>
                    <tr><td colspan="6">Data user belum tersedia.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php render_footer(); ?>
