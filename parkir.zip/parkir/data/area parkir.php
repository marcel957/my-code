<?php
require_once __DIR__ . '/../inc/app.php';
login('../index.php');
allow(['admin'], '../tampilan.php');

if (isset($_POST['simpan'])) {
    $nama = mysqli_real_escape_string($mysqli, $_POST['nama_area']);
    $kap = mysqli_real_escape_string($mysqli, $_POST['kapasitas']);
    $terisi = mysqli_real_escape_string($mysqli, $_POST['terisi']);
    $detail = "$nama ($terisi/$kap)";
    if (isset($_POST['id'])) {
        $id = (int)$_POST['id'];
        mysqli_query($mysqli, "UPDATE tb_area_parkir SET nama_area='$nama', kapasitas='$kap', terisi='$terisi' WHERE id_area=$id");
        log_aktivitas(user_id(), "UBAH Area Parkir - $detail");
    } else {
        mysqli_query($mysqli, "INSERT INTO tb_area_parkir (nama_area, kapasitas, terisi) VALUES ('$nama', '$kap', '$terisi')");
        log_aktivitas(user_id(), "TAMBAH Area Parkir - $detail");
    }
    go('area parkir.php');
}

if (isset($_GET['del'])) {
    $id = (int)$_GET['del'];
    $r = mysqli_fetch_assoc(mysqli_query($mysqli, "SELECT nama_area FROM tb_area_parkir WHERE id_area=$id LIMIT 1"));
    log_aktivitas(user_id(), "HAPUS Area Parkir - " . ($r ? $r['nama_area'] : "ID $id"));
    mysqli_query($mysqli, "DELETE FROM tb_area_parkir WHERE id_area=$id");
    go('area parkir.php');
}

$edit = null;
if (isset($_GET['edit'])) {
    $r = mysqli_query($mysqli, "SELECT * FROM tb_area_parkir WHERE id_area=" . (int)$_GET['edit']);
    $edit = mysqli_fetch_assoc($r);
}

$data = mysqli_query($mysqli, "SELECT * FROM tb_area_parkir LIMIT 200");
$title = 'Area Parkir';
$active = 'area';
$base = '../';
include __DIR__ . '/../inc/header.php';
?>

<div class="page-header">
    <h1 class="page-title"><span class="title-icon"><i class="bi bi-p-square-fill"></i></span> Area Parkir</h1>
    <div class="page-toolbar">
        <div class="search-wrap"><span class="search-icon"><i class="bi bi-search"></i></span><input type="text" placeholder="Cari..." id="searchArea"></div>
        <button type="button" class="icon-btn" title="Pengaturan"><i class="bi bi-gear"></i></button>
        <button type="button" class="icon-btn" title="Daftar"><i class="bi bi-list-ul"></i></button>
        <a href="area parkir.php" class="btn primary"><i class="bi bi-plus-lg"></i> Tambah Area</a>
    </div>
</div>

<div class="grid grid-2">
    <div class="card">
        <div class="label"><?php echo isset($_GET['edit']) ? 'Edit Area' : 'Tambah Area'; ?></div>
        <form method="POST" class="form">
            <?php if (isset($_GET['edit'])): ?><input type="hidden" name="id" value="<?php echo $edit['id_area']; ?>"><?php endif; ?>
            <div class="form-grid">
                <div><label>Nama Area</label><input type="text" name="nama_area" value="<?php echo isset($edit) ? h($edit['nama_area']) : ''; ?>" required></div>
                <div><label>Kapasitas</label><input type="number" min="0" name="kapasitas" value="<?php echo isset($edit) ? $edit['kapasitas'] : ''; ?>" required></div>
                <div><label>Terisi</label><input type="number" min="0" name="terisi" value="<?php echo isset($edit) ? $edit['terisi'] : ''; ?>" required></div>
            </div>
            <div class="actions">
                <button class="btn" type="submit" name="simpan">Simpan</button>
                <button class="btn secondary" type="reset">Reset</button>
                <?php if (isset($_GET['edit'])): ?><a class="btn secondary" href="area parkir.php">Batal</a><?php endif; ?>
            </div>
        </form>
    </div>
    <div class="card">
        <div class="label">Data Area</div>
        <div class="table-wrap">
        <table class="table">
            <thead><tr><th>No.</th><th>Nama Area</th><th>Kapasitas</th><th>Terisi</th><th>Persentase</th><th>Aksi</th></tr></thead>
            <tbody>
                <?php $no = 1; if ($data && mysqli_num_rows($data) > 0): while ($row = mysqli_fetch_assoc($data)): ?>
                <?php 
                    $persen = ($row['kapasitas'] > 0) ? round(($row['terisi'] / $row['kapasitas']) * 100) : 0;
                    $warna = ($persen >= 80) ? '#ff4444' : (($persen >= 50) ? '#ffaa00' : '#44aa44');
                ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo h($row['nama_area']); ?></td>
                        <td><?php echo h($row['kapasitas']); ?></td>
                        <td><?php echo h($row['terisi'] . '/' . $row['kapasitas']); ?></td>
                        <td><div style="background: #f0f0f0; padding: 5px; border-radius: 3px;"><div style="width: <?php echo $persen; ?>%; background: <?php echo $warna; ?>; height: 20px; border-radius: 3px; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 12px;"><?php echo $persen; ?>%</div></div></td>
                        <td>
                            <div class="table-actions">
                                <a class="btn-icon" href="area parkir.php?edit=<?php echo $row['id_area']; ?>" title="Edit"><i class="bi bi-pencil"></i></a>
                                <a class="btn-icon danger" href="area parkir.php?del=<?php echo $row['id_area']; ?>" onclick="return confirm('Hapus?')" title="Hapus"><i class="bi bi-trash"></i></a>
                            </div>
                        </td>
                    </tr>
                <?php endwhile; else: ?>
                    <tr><td colspan="5">Data area belum tersedia.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>

<?php render_footer(); ?>
