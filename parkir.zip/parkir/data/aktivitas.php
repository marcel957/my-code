<?php
require_once __DIR__ . '/../inc/app.php';
login('../index.php');
allow(['admin'], '../tampilan.php');

$tgl = isset($_GET['tgl']) && $_GET['tgl'] !== '' ? mysqli_real_escape_string($mysqli, trim($_GET['tgl'])) : date('Y-m-d');
$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$where = ["DATE(l.waktu_aktivitas) = '$tgl'"];
if ($q) {
    $q_esc = mysqli_real_escape_string($mysqli, $q);
    $where[] = "(l.aktivitas LIKE '%$q_esc%' OR u.nama_lengkap LIKE '%$q_esc%' OR u.username LIKE '%$q_esc%')";
}
$where_sql = implode(' AND ', $where);

$data = mysqli_query($mysqli, "SELECT l.*, u.nama_lengkap, u.username FROM tb_log_aktivitas l LEFT JOIN tb_user u ON l.id_user = u.id_user WHERE $where_sql ORDER BY l.waktu_aktivitas DESC LIMIT 500");

$title = 'Log Aktivitas';
$active = 'aktivitas';
$base = '../';
include __DIR__ . '/../inc/header.php';
?>

<div class="page-header">
    <h1 class="page-title">
        <span class="title-icon"><i class="bi bi-clipboard-data"></i></span>
        Log Aktivitas <span style="font-size:0.85em;color:#666;font-weight:normal;">(Hanya baca - transparan)</span>
    </h1>
    <div class="page-toolbar">
        <form method="GET" class="filter-form" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
            <input type="date" name="tgl" value="<?php echo h($tgl); ?>" class="filter-date" title="Filter tanggal">
            <input type="text" name="q" value="<?php echo h($q); ?>" placeholder="Cari aktivitas/user..." style="min-width:180px;">
            <button type="submit" class="btn secondary"><i class="bi bi-search"></i> Filter</button>
        </form>
    </div>
</div>

<div class="card">
    <div class="label">Riwayat Aktivitas Otomatis</div>
    <p style="margin-bottom:12px;font-size:0.9em;color:#666;">Log ini otomatis tercatat. Tidak dapat diedit atau dihapus.</p>
    <div class="table-wrap">
        <table class="table" id="tableAktivitas">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Waktu</th>
                    <th>User</th>
                    <th>Aktivitas</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($data && mysqli_num_rows($data) > 0): $no = 1; while ($row = mysqli_fetch_assoc($data)): ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo h(dt($row['waktu_aktivitas'])); ?></td>
                        <td><?php echo h($row['nama_lengkap'] ? $row['nama_lengkap'] . ' (' . $row['username'] . ')' : ($row['username'] ?? 'ID ' . $row['id_user'])); ?></td>
                        <td><?php echo h($row['aktivitas']); ?></td>
                    </tr>
                <?php endwhile; else: ?>
                    <tr><td colspan="4">Tidak ada aktivitas pada tanggal ini.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php render_footer(); ?>
