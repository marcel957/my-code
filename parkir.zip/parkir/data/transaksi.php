<?php
require_once __DIR__ . '/../inc/app.php';
login('../index.php');
allow(['admin', 'petugas'], '../tampilan.php');

function to_db_dt($v) {
    if (!$v) return '';
    $v = str_replace('T', ' ', $v);
    return strlen($v) === 16 ? $v . ':00' : $v;
}

function to_local_dt($v) {
    if (!$v) return '';
    return substr(str_replace(' ', 'T', $v), 0, 16);
}

function durasi_jam($in, $out) {
    if (!$in || !$out) return 0;
    $j = (int)ceil((strtotime($out) - strtotime($in)) / 3600);
    return $j > 0 ? $j : 1;
}

$del = isset($_GET['del']);
$cetak = isset($_GET['cetak']);
$edit = isset($_GET['edit']);

if (isset($_POST['simpan'])) {
    $kend = (int)$_POST['id_kendaraan'];
    $in = to_db_dt($_POST['waktu_masuk'] ?? '');
    $out = to_db_dt($_POST['waktu_keluar'] ?? '');
    $tar = (int)$_POST['id_tarif'];
    $dur = (int)$_POST['durasi_jam'];
    $biaya = (float)$_POST['biaya_total'];
    $stat = $_POST['status'] ?? 'masuk';
    $user = (int)$_POST['id_user'];
    $area = (int)$_POST['id_area'];
    
    if ($in && $out && !$dur) {
        $dur = durasi_jam($in, $out);
    }
    
    if ($dur && !$biaya && $tar) {
        $tr = mysqli_fetch_assoc(mysqli_query($mysqli, "SELECT tarif_per_jam FROM tb_tarif WHERE id_tarif=$tar"));
        if ($tr) $biaya = $dur * (float)$tr['tarif_per_jam'];
    }
    $wk = $out ? "'$out'" : "NULL";
    $dj = $dur ? $dur : "NULL";
    $bt = $biaya ? $biaya : "NULL";

    $detail = "ID $kend - $stat";
    
    if (isset($_POST['id'])) {
        $id = (int)$_POST['id'];
        $lama = mysqli_fetch_assoc(mysqli_query($mysqli, "SELECT status, id_area FROM tb_transaksi WHERE id_parkir=$id"));
        $st_lama = $lama['status'];
        $area_lama = $lama['id_area'];
        
        mysqli_query($mysqli, "UPDATE tb_transaksi SET id_kendaraan=$kend, waktu_masuk='$in', waktu_keluar=$wk, id_tarif=$tar, durasi_jam=$dj, biaya_total=$bt, status='$stat', id_user=$user, id_area=$area WHERE id_parkir=$id");
        
        if ($st_lama != $stat || $area_lama != $area) {
            if ($st_lama == 'masuk') {
                mysqli_query($mysqli, "UPDATE tb_area_parkir SET terisi = terisi - 1 WHERE id_area = $area_lama");
            }
            if ($stat == 'masuk') {
                mysqli_query($mysqli, "UPDATE tb_area_parkir SET terisi = terisi + 1 WHERE id_area = $area");
            }
        }
        
        log_aktivitas(user_id(), "UBAH Transaksi - $detail");
    } else {
        mysqli_query($mysqli, "INSERT INTO tb_transaksi (id_kendaraan, waktu_masuk, waktu_keluar, id_tarif, durasi_jam, biaya_total, status, id_user, id_area) VALUES ($kend, '$in', $wk, $tar, $dj, $bt, '$stat', $user, $area)");
        
        if ($stat == 'masuk') {
            mysqli_query($mysqli, "UPDATE tb_area_parkir SET terisi = terisi + 1 WHERE id_area = $area");
        }
        
        log_aktivitas(user_id(), "TAMBAH Transaksi - $detail");
    }
    go('transaksi.php');
}

if ($del) {
    $id = (int)$_GET['del'];
    mysqli_query($mysqli, "DELETE FROM tb_transaksi WHERE id_parkir=$id");
    log_aktivitas(user_id(), "HAPUS Transaksi - ID $id");
    go('transaksi.php');
}

if ($cetak) {
    $id = (int)$_GET['cetak'];
    $r = mysqli_query($mysqli, "SELECT t.*, k.plat_nomor, k.jenis_kendaraan, k.pemilik, tr.tarif_per_jam, u.nama_lengkap, a.nama_area FROM tb_transaksi t LEFT JOIN tb_kendaraan k ON t.id_kendaraan=k.Id_kendaraaan LEFT JOIN tb_tarif tr ON t.id_tarif=tr.id_tarif LEFT JOIN tb_user u ON t.id_user=u.id_user LEFT JOIN tb_area_parkir a ON t.id_area=a.id_area WHERE t.id_parkir=$id LIMIT 1");
    $row = mysqli_fetch_assoc($r);
    if (!$row) exit("Data tidak ditemukan");
    $dur = $row['durasi_jam'] ?: durasi_jam($row['waktu_masuk'], $row['waktu_keluar']);
    $total = $row['biaya_total'] ?: ((float)$row['tarif_per_jam'] * $dur);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Struk Parkir</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 12px; }
        .box { width: 280px; margin: 0 auto; border: 1px solid #ddd; padding: 10px; }
        .row { display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 4px; }
        .title { font-weight: bold; text-align: center; margin-bottom: 8px; }
        .line { border-top: 1px dashed #ccc; margin: 6px 0; }
        .actions { text-align: center; margin-top: 10px; }
        @media print { .actions { display: none; } }
    </style>
</head>
<body>
    <div class="box">
        <div class="title">STRUK PARKIR</div>
        <div class="row"><span>ID</span><span><?php echo h($row['id_parkir']); ?></span></div>
        <div class="row"><span>Plat</span><span><?php echo h($row['plat_nomor'] ?: '-'); ?></span></div>
        <div class="row"><span>Jenis</span><span><?php echo h($row['jenis_kendaraan'] ?: '-'); ?></span></div>
        <div class="line"></div>
        <div class="row"><span>Masuk</span><span><?php echo h($row['waktu_masuk']); ?></span></div>
        <div class="row"><span>Keluar</span><span><?php echo h($row['waktu_keluar'] ?: '-'); ?></span></div>
        <div class="row"><span>Durasi</span><span><?php echo h($dur ? $dur . ' jam' : '-'); ?></span></div>
        <div class="line"></div>
        <div class="row"><strong>Total</strong><strong><?php echo h(rupiah($total)); ?></strong></div>
    </div>
    <div class="actions">
        <button onclick="window.print()">Cetak</button>
        <a href="transaksi.php">Kembali</a>
    </div>
</body>
</html>
<?php
    exit;
}

$edit_trx = null;
if ($edit) {
    $r = mysqli_query($mysqli, "SELECT * FROM tb_transaksi WHERE id_parkir=" . (int)$_GET['edit']);
    $edit_trx = mysqli_fetch_assoc($r);
}

$list_kendaraan = mysqli_query($mysqli, "SELECT Id_kendaraaan, plat_nomor, jenis_kendaraan, pemilik FROM tb_kendaraan ORDER BY plat_nomor");
$list_tarif = mysqli_query($mysqli, "SELECT id_tarif, jenis_kendaraan, tarif_per_jam FROM tb_tarif ORDER BY jenis_kendaraan");
$list_user = mysqli_query($mysqli, "SELECT id_user, nama_lengkap, username FROM tb_user ORDER BY nama_lengkap");
$list_area = mysqli_query($mysqli, "SELECT id_area, nama_area, terisi, kapasitas FROM tb_area_parkir ORDER BY nama_area");
$data_transaksi = mysqli_query($mysqli, "SELECT t.id_parkir, t.waktu_masuk, t.waktu_keluar, t.durasi_jam, t.biaya_total, t.status, k.plat_nomor, k.jenis_kendaraan, tr.tarif_per_jam, u.nama_lengkap, a.nama_area FROM tb_transaksi t LEFT JOIN tb_kendaraan k ON t.id_kendaraan=k.Id_kendaraaan LEFT JOIN tb_tarif tr ON t.id_tarif=tr.id_tarif LEFT JOIN tb_user u ON t.id_user=u.id_user LEFT JOIN tb_area_parkir a ON t.id_area=a.id_area ORDER BY t.id_parkir LIMIT 200");

$title = 'Transaksi';
$active = 'transaksi';
$base = '../';
include __DIR__ . '/../inc/header.php';
?>

<div class="grid grid-2">
    <div class="card">
        <div class="label"><?php echo $edit ? 'Ubah Data' : 'Tambah Data'; ?></div>
        <form method="POST" class="form">
            <?php if ($edit): ?><input type="hidden" name="id" value="<?php echo $edit_trx['id_parkir']; ?>"><?php endif; ?>
            <div class="form-grid">
                <div><label>Kendaraan</label>
                    <select name="id_kendaraan" required>
                        <option value="">Pilih</option>
                        <?php mysqli_data_seek($list_kendaraan, 0); while ($k = mysqli_fetch_assoc($list_kendaraan)): ?>
                            <option value="<?php echo $k['Id_kendaraaan']; ?>" <?php echo (isset($edit_trx) && $edit_trx['id_kendaraan'] == $k['Id_kendaraaan']) ? 'selected' : ''; ?>><?php echo $k['plat_nomor'] . ' - ' . $k['jenis_kendaraan']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div><label>Jam Masuk</label><input type="datetime-local" name="waktu_masuk" value="<?php echo isset($edit_trx) ? to_local_dt($edit_trx['waktu_masuk']) : ''; ?>" required></div>
                <div><label>Jam Keluar</label><input type="datetime-local" name="waktu_keluar" value="<?php echo isset($edit_trx) ? to_local_dt($edit_trx['waktu_keluar']) : ''; ?>"></div>
                <div><label>Tarif</label>
                    <select name="id_tarif" id="selectTarif" required onchange="hitungTotal()">
                        <option value="">Pilih</option>
                        <?php mysqli_data_seek($list_tarif, 0); while ($t = mysqli_fetch_assoc($list_tarif)): ?>
                            <option value="<?php echo $t['id_tarif']; ?>" data-tarif="<?php echo $t['tarif_per_jam']; ?>" <?php echo (isset($edit_trx) && $edit_trx['id_tarif'] == $t['id_tarif']) ? 'selected' : ''; ?>><?php echo $t['jenis_kendaraan'] . ' - ' . rupiah($t['tarif_per_jam']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div><label>Lama (jam)</label><input type="number" name="durasi_jam" id="inputDurasi" min="1" value="<?php echo isset($edit_trx) ? $edit_trx['durasi_jam'] : ''; ?>" onchange="hitungTotal()" oninput="hitungTotal()"></div>
                <div><label>Total</label><input type="number" name="biaya_total" id="inputBiaya" step="0.01" value="<?php echo isset($edit_trx) ? $edit_trx['biaya_total'] : ''; ?>" readonly style="background-color: #f5f5f5;"></div>
                <div><label>Status</label>
                    <select name="status" required>
                        <option value="masuk" <?php echo (isset($edit_trx) && $edit_trx['status'] == 'masuk') ? 'selected' : ''; ?>>Masuk</option>
                        <option value="keluar" <?php echo (isset($edit_trx) && $edit_trx['status'] == 'keluar') ? 'selected' : ''; ?>>Keluar</option>
                    </select>
                </div>
                <div><label>Petugas</label>
                    <select name="id_user" required>
                        <option value="">Pilih</option>
                        <?php mysqli_data_seek($list_user, 0); while ($u = mysqli_fetch_assoc($list_user)): ?>
                            <option value="<?php echo $u['id_user']; ?>" <?php echo (isset($edit_trx) && $edit_trx['id_user'] == $u['id_user']) ? 'selected' : ''; ?>><?php echo $u['nama_lengkap'] . ' (' . $u['username'] . ')'; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="full"><label>Area</label>
                    <select name="id_area" required>
                        <option value="">Pilih</option>
                        <?php mysqli_data_seek($list_area, 0); while ($a = mysqli_fetch_assoc($list_area)): ?>
                            <option value="<?php echo $a['id_area']; ?>" <?php echo (isset($edit_trx) && $edit_trx['id_area'] == $a['id_area']) ? 'selected' : ''; ?>><?php echo $a['nama_area'] . ' (' . $a['terisi'] . '/' . $a['kapasitas'] . ')'; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
            </div>
            <div class="actions">
                <button class="btn" type="submit" name="simpan">Simpan</button>
                <button class="btn secondary" type="reset">Ulang</button>
                <?php if ($edit): ?><a class="btn secondary" href="transaksi.php">Batal</a><?php endif; ?>
            </div>
        </form>
    </div>
    <div class="card">
        <div class="label">Data Transaksi</div>
        <div class="table-wrap">
        <table class="table">
            <thead>
                <tr><th>ID</th><th>Kendaraan</th><th>Masuk</th><th>Keluar</th><th>Tarif</th><th>Lama</th><th>Biaya</th><th>Status</th><th>Area</th><th>Aksi</th></tr>
            </thead>
            <tbody>
                <?php if ($data_transaksi && mysqli_num_rows($data_transaksi) > 0): while ($row = mysqli_fetch_assoc($data_transaksi)): ?>
                    <tr>
                        <td><?php echo h($row['id_parkir']); ?></td>
                        <td><?php echo h($row['plat_nomor'] ? $row['plat_nomor'] . ' - ' . $row['jenis_kendaraan'] : '-'); ?></td>
                        <td><?php echo h(dt($row['waktu_masuk'])); ?></td>
                        <td><?php echo h(dt($row['waktu_keluar'])); ?></td>
                        <td><?php echo h($row['jenis_kendaraan'] ? $row['jenis_kendaraan'] . ' - ' . rupiah($row['tarif_per_jam']) : '-'); ?></td>
                        <td><?php echo h($row['durasi_jam'] ? $row['durasi_jam'] . ' jam' : '-'); ?></td>
                        <td><?php echo h(rupiah($row['biaya_total'])); ?></td>
                        <td><?php echo h($row['status']); ?></td>
                        <td><?php echo h($row['nama_area'] ?: '-'); ?></td>
                        <td>
                            <div class="table-actions">
                                <a class="btn-icon" href="transaksi.php?cetak=<?php echo $row['id_parkir']; ?>" target="_blank" title="Cetak"><i class="bi bi-printer"></i></a>
                                <a class="btn-icon" href="transaksi.php?edit=<?php echo $row['id_parkir']; ?>" title="Edit"><i class="bi bi-pencil"></i></a>
                                <a class="btn-icon danger" href="transaksi.php?del=<?php echo $row['id_parkir']; ?>" onclick="return confirm('Hapus?')" title="Hapus"><i class="bi bi-trash"></i></a>
                            </div>
                        </td>
                    </tr>
                <?php endwhile; else: ?>
                    <tr><td colspan="10">Data belum ada.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>

<script>
function hitungTotal() {
    var tar = document.getElementById('selectTarif');
    var dur = document.getElementById('inputDurasi');
    var tot = document.getElementById('inputBiaya');
    var pilih = tar.options[tar.selectedIndex];
    var harga = pilih.getAttribute('data-tarif');
    var jam = dur.value;
    var hasil = harga * jam;
    if (harga > 0 && jam > 0) {
        tot.value = hasil.toFixed(2);
    } else {
        tot.value = '';
    }
}

window.onload = function() {
    hitungTotal();
}
</script>
<?php render_footer(); ?>
