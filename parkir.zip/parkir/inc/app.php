<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../koneksi.php';

// HELPER FUNCTIONS - Fungsi Pembantu Sederhana
function h($s) { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
function role() { return $_SESSION['role'] ?? 'guest'; }
function user_name() { return $_SESSION['nama'] ?? 'User'; }
function user_id() { return (int)($_SESSION['user_id'] ?? 0); }
function go($url) { header('Location: ' . $url); exit; }

// CEK LOGIN
function login($redirect = 'index.php') { 
    if (!isset($_SESSION['user_id'])) go($redirect); 
}

// CEK ROLE (Verifikasi akses sesuai role)
function allow($roles, $redirect = 'tampilan.php') { 
    if (!in_array(role(), $roles, true)) go($redirect); 
}


function val($sql) {
    global $mysqli;
    $result = mysqli_query($mysqli, $sql);
    if ($result && $row = mysqli_fetch_row($result)) return $row[0];
    return 0;
}

function rupiah($n) {
    if (!$n) return '-';
    return 'Rp ' . number_format($n, 0, ',', '.');
}

function dt($t) {
    if (!$t) return '-';
    return date('d/m/Y H:i', strtotime($t));
}

function log_aktivitas($id_user, $teks) {
    global $mysqli;
    $id_user = (int)$id_user;
    $teks = htmlspecialchars($teks, ENT_QUOTES, 'UTF-8');
    $waktu = date('Y-m-d H:i:s');
    mysqli_query($mysqli, "INSERT INTO tb_log_aktivitas (id_user, aktivitas, waktu_aktivitas) VALUES ($id_user, '$teks', '$waktu')");
}

function menu_items($base = '') {
    $role = role();
    
    if ($role === 'admin') return [
        ['dashboard', 'Dashboard', $base . 'dashboard_admin.php', 'bi-grid-1x2-fill'],
        ['tarif', 'Tarif Parkir', $base . 'data/tarif.php', 'bi-receipt'],
        ['area', 'Area Parkir', $base . 'data/area parkir.php', 'bi-p-square-fill'],
        ['kendaraan', 'Kendaraan', $base . 'data/kendaraan.php', 'bi-car-front-fill'],
        ['user', 'User', $base . 'data/user.php', 'bi-person'],
        ['aktivitas', 'Log Aktivitas', $base . 'data/aktivitas.php', 'bi-clipboard-data'],
    ];
    
    if ($role === 'petugas') return [
        ['dashboard', 'Dashboard', $base . 'dashboard_petugas.php', 'bi-grid-1x2-fill'],
        ['transaksi', 'Transaksi', $base . 'data/transaksi.php', 'bi-arrow-repeat'],
    ];
    
    if ($role === 'owner') return [
        ['dashboard', 'Dashboard', $base . 'dashboard_owner.php', 'bi-grid-1x2-fill'],
    ];
    
    return [];
}
?>
