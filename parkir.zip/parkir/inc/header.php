<?php
require_once __DIR__ . '/app.php';
$title = $title ?? 'Dashboard';
$active = $active ?? '';
$base = $base ?? '';
$menu = menu_items($base);
$role = role();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo h($title); ?> - Parkir</title>
    <link rel="stylesheet" href="<?php echo h($base . 'assets/app.css'); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body>
    <div class="wrap">
        <aside class="sidebar">
            <div class="logo-wrap">
                <div class="logo-text">PARKIR</div>
                <div class="logo-icon"><i class="bi bi-car-front-fill"></i></div>
            </div>
            <nav class="nav">
                <?php foreach ($menu as $item): ?>
                    <a class="link <?php echo $active === $item[0] ? 'active' : ''; ?>" href="<?php echo h($item[2]); ?>">
                        <span class="nav-icon"><i class="bi <?php echo h($item[3] ?? 'bi-circle'); ?>"></i></span>
                        <?php echo h($item[1]); ?>
                    </a>
                <?php endforeach; ?>
            </nav>
            <a class="link logout" href="<?php echo h($base . 'index.php?logout=1'); ?>">
                <span class="nav-icon"><i class="bi bi-box-arrow-right"></i></span>
                Keluar
            </a>
        </aside>
        <main class="main">
            <div class="topbar">
                <div class="title"><?php echo h($title); ?></div>
                <div class="topbar-right">
                    <button type="button" class="icon-btn" title="Pengaturan"><i class="bi bi-gear"></i></button>
                    <button type="button" class="icon-btn" title="User"><i class="bi bi-person"></i></button>
                    <span class="user-info"><?php echo h(user_name()); ?> (<?php echo h($role); ?>)</span>
                </div>
            </div>
            <div class="content">

<?php
if (!function_exists('render_footer')) {
    function render_footer() {
?>
            </div>
        </main>
    </div>
</body>
</html>
<?php
    }
}
?>
