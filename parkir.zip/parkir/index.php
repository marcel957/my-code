<?php
require_once __DIR__ . '/inc/app.php';

//LOGOUT
if (isset($_GET['logout'])) {
    if (user_id()) log_aktivitas(user_id(), "LOGOUT - Keluar dari sistem");
    session_destroy();
    go('index.php');
}

if (isset($_SESSION['user_id'])) go('tampilan.php');
$error = '';

// PROSES LOGIN
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    // VALIDASI
    if (!$username || !$password) {
        $error = 'Isi semua.';
    } else {
        // PERIKSA APAKAH USER EXIST
        global $mysqli;
        $sql = "SELECT * FROM tb_user WHERE username='$username' LIMIT 1";
        $result = mysqli_query($mysqli, $sql);
        $user = mysqli_fetch_assoc($result);
        
        // VERIFIKASI DATA USER
        if (!$user) {
            $error = 'User tidak ada.';
        } elseif ($user['status_aktif'] != '1') {
            $error = 'Akun belum aktif.';
        } elseif ($user['password'] !== $password) {
            $error = 'Password salah.';
        } else {
            // LOGIN BERHASIL - SIMPAN SESSION
            $_SESSION['user_id'] = $user['id_user'];
            $_SESSION['nama'] = $user['nama_lengkap'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            log_aktivitas($user['id_user'], "LOGIN - Masuk ke sistem");
            go('tampilan.php');
        }
    }
}
?>

<!-- tampilan login -->
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Parkir</title>
    <link rel="stylesheet" href="assets/app.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body class="login-page">
    <div class="login-card">
        <div class="logo-wrap">
            <div class="logo-text">PARKIR</div>
            <div class="logo-icon"><i class="bi bi-car-front-fill"></i></div>
        </div>
        <form method="post" autocomplete="off" class="form">
            <div class="form-group">
                <div class="input-wrap">
                    <span class="input-icon"><i class="bi bi-person"></i></span>
                    <input type="text" name="username" value="<?php echo h($_POST['username'] ?? ''); ?>" placeholder="Username" required>
                </div>
            </div>
            <div class="form-group">
                <div class="input-wrap">
                    <span class="input-icon"><i class="bi bi-lock"></i></span>
                    <input type="password" name="password" placeholder="Password" required>
                </div>
            </div>
            <button class="btn-login" type="submit">Login</button>
        </form>
        <a href="#" class="forgot-link">Lupa password?</a>
        <?php if ($error): ?><div class="alert"><?php echo h($error); ?></div><?php endif; ?>
    </div>
</body>
</html>
