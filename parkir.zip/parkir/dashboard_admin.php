<?php
require_once __DIR__ . '/inc/app.php';
login('index.php');
allow(['admin'], 'tampilan.php');

$jumlah_tarif = (int)val("SELECT COUNT(*) FROM tb_tarif");
$jumlah_area = (int)val("SELECT COUNT(*) FROM tb_area_parkir");
$jumlah_kendaraan = (int)val("SELECT COUNT(*) FROM tb_kendaraan");
$trx_hari = (int)val("SELECT COUNT(*) FROM tb_transaksi WHERE DATE(waktu_masuk) = CURDATE()");
$pendapatan_hari = (float)val("SELECT COALESCE(SUM(biaya_total),0) FROM tb_transaksi WHERE DATE(waktu_masuk) = CURDATE()");

$log_aktivitas = mysqli_query($mysqli, "SELECT l.waktu_aktivitas, l.aktivitas, u.nama_lengkap, u.username FROM tb_log_aktivitas l LEFT JOIN tb_user u ON l.id_user=u.id_user ORDER BY l.waktu_aktivitas DESC LIMIT 5");
$trx_terbaru = mysqli_query($mysqli, "SELECT t.id_parkir, t.waktu_masuk, t.status, t.biaya_total, k.plat_nomor FROM tb_transaksi t LEFT JOIN tb_kendaraan k ON t.id_kendaraan=k.Id_kendaraaan ORDER BY t.waktu_masuk DESC LIMIT 5");

$title = 'Dashboard';
$active = 'dashboard';
$base = '';
include __DIR__ . '/inc/header.php';
?>

<div class="grid grid-4">
    <div class="stat-card stat-blue">
        <div class="label">Tarif Parkir</div>
        <div class="big"><?php echo h($jumlah_tarif); ?></div>
        <span class="stat-icon"><i class="bi bi-car-front-fill"></i></span>
    </div>
    <div class="stat-card stat-green">
        <div class="label">Area Parkir</div>
        <div class="big"><?php echo h($jumlah_area); ?></div>
        <span class="stat-icon"><i class="bi bi-p-square-fill"></i></span>
    </div>
    <div class="stat-card stat-orange">
        <div class="label">Total Kendaraan</div>
        <div class="big"><?php echo h($jumlah_kendaraan); ?></div>
        <span class="stat-icon"><i class="bi bi-car-front-fill"></i></span>
    </div>
    <div class="stat-card stat-purple">
        <div class="label">Transaksi Hari Ini</div>
        <div class="big"><?php echo h($trx_hari); ?></div>
        <div class="small"><?php echo h(rupiah($pendapatan_hari)); ?></div>
        <span class="stat-icon"><i class="bi bi-arrow-repeat"></i></span>
    </div>
</div>

<div class="card">
    <div class="section-title">Log Aktivitas Terbaru</div>
    <div class="table-wrap">
        <table class="table">
            <thead><tr><th>Waktu</th><th>User</th><th>Aktivitas</th></tr></thead>
            <tbody>
                <?php if ($log_aktivitas && mysqli_num_rows($log_aktivitas) > 0): while ($row = mysqli_fetch_assoc($log_aktivitas)): ?>
                    <tr>
                        <td><?php echo h(dt($row['waktu_aktivitas'])); ?></td>
                        <td><?php echo h($row['nama_lengkap'] ?: ($row['username'] ?? '-')); ?></td>
                        <td><?php echo h($row['aktivitas']); ?></td>
                    </tr>
                <?php endwhile; else: ?>
                    <tr><td colspan="3">Belum ada aktivitas.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="pagination">
        <a href="data/aktivitas.php" class="page-btn"><i class="bi bi-chevron-left"></i></a>
        <span class="page-btn active">1</span>
        <a href="data/aktivitas.php" class="page-btn"><i class="bi bi-chevron-right"></i></a>
        <span class="page-info">1-<?php echo $log_aktivitas ? mysqli_num_rows($log_aktivitas) : 0; ?> dari <?php echo $log_aktivitas ? mysqli_num_rows($log_aktivitas) : 0; ?></span>
    </div>
    <div class="actions"><a class="btn secondary" href="data/aktivitas.php">Lihat Semua</a></div>
</div>

<?php render_footer(); ?>
