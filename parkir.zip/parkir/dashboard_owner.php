<?php
require_once __DIR__ . '/inc/app.php';
login('index.php');
allow(['owner'], 'tampilan.php');

function tgl_aman($v, $def) {
    if (!$v) return $def;
    $d = DateTime::createFromFormat('Y-m-d', $v);
    return $d ? $d->format('Y-m-d') : $def;
}

$export = $_GET['export'] ?? '';
$start = tgl_aman($_GET['start'] ?? '', date('Y-m-01'));
$end = tgl_aman($_GET['end'] ?? '', date('Y-m-d'));
if ($start > $end) list($start, $end) = [$end, $start];

$where = "DATE(t.waktu_masuk) BETWEEN '$start' AND '$end'";
$total = (int)val("SELECT COUNT(*) FROM tb_transaksi t WHERE $where");
$income = (float)val("SELECT COALESCE(SUM(t.biaya_total),0) FROM tb_transaksi t WHERE $where");
$masuk = (int)val("SELECT COUNT(*) FROM tb_transaksi t WHERE $where AND t.status='masuk'");
$keluar = (int)val("SELECT COUNT(*) FROM tb_transaksi t WHERE $where AND t.status='keluar'");

$rekap_sql = "SELECT t.id_parkir, t.waktu_masuk, t.waktu_keluar, t.status, t.biaya_total, k.plat_nomor, tr.jenis_kendaraan FROM tb_transaksi t LEFT JOIN tb_kendaraan k ON t.id_kendaraan=k.Id_kendaraaan LEFT JOIN tb_tarif tr ON t.id_tarif=tr.id_tarif WHERE $where ORDER BY t.waktu_masuk DESC";

if ($export === 'excel') {
    $rekap = mysqli_query($mysqli, $rekap_sql);
    header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
    header('Content-Disposition: attachment; filename="rekap-transaksi-' . $start . '-' . $end . '.xls"');
    header('Cache-Control: max-age=0');
    echo "\xEF\xBB\xBF";
?>
<!DOCTYPE html>
<html lang="id">
<head><meta charset="UTF-8"><title>Rekap Transaksi</title></head>
<body>
    <table border="1" cellpadding="4" cellspacing="0">
        <tr><th colspan="2">Ringkasan</th></tr>
        <tr><td>Periode</td><td><?php echo h($start . ' s/d ' . $end); ?></td></tr>
        <tr><td>Total Transaksi</td><td><?php echo h($total); ?></td></tr>
        <tr><td>Pendapatan (Rp)</td><td><?php echo h($income); ?></td></tr>
        <tr><td>Transaksi Masuk</td><td><?php echo h($masuk); ?></td></tr>
        <tr><td>Transaksi Keluar</td><td><?php echo h($keluar); ?></td></tr>
    </table>
    <br>
    <table border="1" cellpadding="4" cellspacing="0">
        <thead><tr><th>ID</th><th>Plat</th><th>Jenis</th><th>Status</th><th>Masuk</th><th>Keluar</th><th>Total (Rp)</th></tr></thead>
        <tbody>
            <?php if ($rekap && mysqli_num_rows($rekap) > 0): while ($row = mysqli_fetch_assoc($rekap)): ?>
                <tr><td><?php echo h($row['id_parkir']); ?></td><td><?php echo h($row['plat_nomor'] ?: '-'); ?></td><td><?php echo h($row['jenis_kendaraan'] ?: '-'); ?></td><td><?php echo h($row['status']); ?></td><td><?php echo h(dt($row['waktu_masuk'])); ?></td><td><?php echo h(dt($row['waktu_keluar'])); ?></td><td><?php echo h($row['biaya_total'] ?? 0); ?></td></tr>
            <?php endwhile; else: ?><tr><td colspan="7">Data transaksi belum tersedia.</td></tr><?php endif; ?>
        </tbody>
    </table>
</body>
</html>
<?php
    exit;
}

$rekap = mysqli_query($mysqli, $rekap_sql . " LIMIT 200");
$title = 'Dashboard';
$active = 'dashboard';
$base = '';
include __DIR__ . '/inc/header.php';
?>

<div class="card" id="rekap">
    <form class="form-inline" method="get">
        <div class="label">Filter Tanggal</div>
        <input type="date" name="start" value="<?php echo h($start); ?>">
        <input type="date" name="end" value="<?php echo h($end); ?>">
        <button class="btn" type="submit">Terapkan</button>
    </form>
    <div class="actions"><a class="btn secondary" href="dashboard_owner.php?<?php echo h(http_build_query(['start' => $start, 'end' => $end, 'export' => 'excel'])); ?>">Export Excel</a></div>
</div>

<div class="grid grid-4">
    <div class="stat-card stat-blue"><div class="label">Total Transaksi</div><div class="big"><?php echo h($total); ?></div><span class="stat-icon"><i class="bi bi-arrow-repeat"></i></span></div>
    <div class="stat-card stat-green"><div class="label">Pendapatan</div><div class="big"><?php echo h(rupiah($income)); ?></div><span class="stat-icon"><i class="bi bi-currency-dollar"></i></span></div>
    <div class="stat-card stat-orange"><div class="label">Transaksi Masuk</div><div class="big"><?php echo h($masuk); ?></div><span class="stat-icon"><i class="bi bi-box-arrow-in-down"></i></span></div>
    <div class="stat-card stat-purple"><div class="label">Transaksi Keluar</div><div class="big"><?php echo h($keluar); ?></div><span class="stat-icon"><i class="bi bi-box-arrow-up"></i></span></div>
</div>

<div class="card">
    <div class="section-title">Rekap Transaksi</div>
    <div class="table-wrap">
    <table class="table">
        <thead><tr><th>ID</th><th>Plat</th><th>Jenis</th><th>Status</th><th>Masuk</th><th>Keluar</th><th>Total</th></tr></thead>
        <tbody>
            <?php if ($rekap && mysqli_num_rows($rekap) > 0): while ($row = mysqli_fetch_assoc($rekap)): ?>
                <tr><td><?php echo h($row['id_parkir']); ?></td><td><?php echo h($row['plat_nomor'] ?: '-'); ?></td><td><?php echo h($row['jenis_kendaraan'] ?: '-'); ?></td><td><?php echo h($row['status']); ?></td><td><?php echo h(dt($row['waktu_masuk'])); ?></td><td><?php echo h(dt($row['waktu_keluar'])); ?></td><td><?php echo h(rupiah($row['biaya_total'])); ?></td></tr>
            <?php endwhile; else: ?><tr><td colspan="7">Data transaksi belum tersedia.</td></tr><?php endif; ?>
        </tbody>
    </table>
    </div>
</div>

<?php render_footer(); ?>
