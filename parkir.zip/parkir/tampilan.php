<?php
//pemilihan role dashboard
require_once __DIR__ . '/inc/app.php';
login('index.php');
$r = role();
if ($r === 'admin') go('dashboard_admin.php');
if ($r === 'petugas') go('dashboard_petugas.php');
if ($r === 'owner') go('dashboard_owner.php');
go('index.php?logout=1');
?>
