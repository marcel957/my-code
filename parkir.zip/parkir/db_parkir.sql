-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2026 at 05:32 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_parkir`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_area_parkir`
--

CREATE TABLE `tb_area_parkir` (
  `id_area` int(11) NOT NULL,
  `nama_area` varchar(50) NOT NULL,
  `kapasitas` int(5) NOT NULL,
  `terisi` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_area_parkir`
--

INSERT INTO `tb_area_parkir` (`id_area`, `nama_area`, `kapasitas`, `terisi`) VALUES
(1, 'sungai', 54, 0),
(2, 'pondok', 23, 0),
(3, 'lapangan sepak bola', 54, 0),
(4, 'lapangan basket', 19, 0),
(20, 'danau', 76, 0),
(21, 'brotherhood', 30, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_kendaraan`
--

CREATE TABLE `tb_kendaraan` (
  `Id_kendaraaan` int(11) NOT NULL,
  `plat_nomor` varchar(15) NOT NULL,
  `jenis_kendaraan` varchar(20) NOT NULL,
  `warna` varchar(20) NOT NULL,
  `pemilik` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_kendaraan`
--

INSERT INTO `tb_kendaraan` (`Id_kendaraaan`, `plat_nomor`, `jenis_kendaraan`, `warna`, `pemilik`, `id_user`) VALUES
(1, '6645', 'mobil', 'merah', 'rendi', 1),
(2, '6546', 'sepeda motor', 'hitam', 'rangga', 2),
(3, '4568', 'mobil', 'pink', 'rajab', 3),
(4, '7654', 'motor', 'ungu', 'bayu', 4),
(5, '4569', 'mobil', 'hitam', 'marcel', 5),
(43, '2341', 'truk', 'hitam', 'nofal', 12);

-- --------------------------------------------------------

--
-- Table structure for table `tb_log_aktivitas`
--

CREATE TABLE `tb_log_aktivitas` (
  `id_log` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `aktivitas` varchar(100) NOT NULL,
  `waktu_aktivitas` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_log_aktivitas`
--

INSERT INTO `tb_log_aktivitas` (`id_log`, `id_user`, `aktivitas`, `waktu_aktivitas`) VALUES
(24, 3, 'LOGIN - Masuk ke sistem', '2026-02-09 02:46:39'),
(25, 3, 'LOGOUT - Keluar dari sistem', '2026-02-09 02:46:51'),
(26, 12, 'LOGIN - Masuk ke sistem', '2026-02-09 02:47:04'),
(27, 12, 'LOGOUT - Keluar dari sistem', '2026-02-09 02:48:06'),
(28, 21, 'LOGIN - Masuk ke sistem', '2026-02-09 02:48:44'),
(29, 21, 'LOGOUT - Keluar dari sistem', '2026-02-09 02:48:56'),
(30, 3, 'LOGIN - Masuk ke sistem', '2026-02-09 02:53:56'),
(31, 3, 'LOGOUT - Keluar dari sistem', '2026-02-09 02:56:30'),
(32, 21, 'LOGIN - Masuk ke sistem', '2026-02-09 02:59:36'),
(33, 21, 'LOGOUT - Keluar dari sistem', '2026-02-09 03:00:51'),
(34, 3, 'LOGIN - Masuk ke sistem', '2026-02-09 03:01:03'),
(35, 3, 'LOGOUT - Keluar dari sistem', '2026-02-09 03:03:53'),
(36, 3, 'LOGIN - Masuk ke sistem', '2026-02-09 03:06:46'),
(37, 3, 'LOGOUT - Keluar dari sistem', '2026-02-09 03:08:24'),
(38, 12, 'LOGIN - Masuk ke sistem', '2026-02-09 03:11:36'),
(39, 12, 'LOGOUT - Keluar dari sistem', '2026-02-09 03:15:09'),
(40, 3, 'LOGIN - Masuk ke sistem', '2026-02-09 03:15:21'),
(41, 3, 'TAMBAH Transaksi - 4568 - Masuk', '2026-02-09 03:16:15'),
(42, 3, 'LOGOUT - Keluar dari sistem', '2026-02-09 03:24:44'),
(43, 12, 'LOGIN - Masuk ke sistem', '2026-02-09 05:45:12'),
(44, 12, 'LOGOUT - Keluar dari sistem', '2026-02-09 05:46:17'),
(45, 12, 'LOGIN - Masuk ke sistem', '2026-02-09 05:58:02'),
(46, 3, 'LOGIN - Masuk ke sistem', '2026-02-10 01:45:16'),
(47, 3, 'LOGOUT - Keluar dari sistem', '2026-02-10 01:46:05'),
(48, 21, 'LOGIN - Masuk ke sistem', '2026-02-10 01:46:38'),
(49, 21, 'LOGOUT - Keluar dari sistem', '2026-02-10 01:49:12'),
(50, 3, 'LOGIN - Masuk ke sistem', '2026-02-10 01:49:33'),
(51, 3, 'LOGIN - Masuk ke sistem', '2026-02-10 01:58:33'),
(52, 3, 'TAMBAH Transaksi - 6546 - Masuk', '2026-02-10 02:00:31'),
(53, 3, 'UBAH Transaksi - 6546 - Keluar', '2026-02-10 02:00:47'),
(54, 3, 'UBAH Transaksi - 6645 - Keluar', '2026-02-10 02:01:33'),
(55, 3, 'UBAH Transaksi - 6546 - Masuk', '2026-02-10 02:01:49'),
(56, 3, 'UBAH Transaksi - 6546 - Keluar', '2026-02-10 02:02:04'),
(57, 3, 'LOGOUT - Keluar dari sistem', '2026-02-10 02:06:08'),
(58, 12, 'LOGIN - Masuk ke sistem', '2026-02-10 02:07:48'),
(59, 12, 'TAMBAH Tarif - Lainnya - Rp 20.000', '2026-02-10 02:09:12'),
(60, 12, 'LOGOUT - Keluar dari sistem', '2026-02-10 02:14:24'),
(61, 21, 'LOGIN - Masuk ke sistem', '2026-02-10 02:14:27'),
(62, 21, 'LOGOUT - Keluar dari sistem', '2026-02-10 02:16:34'),
(63, 3, 'LOGIN - Masuk ke sistem', '2026-02-10 04:10:53'),
(64, 3, 'LOGOUT - Keluar dari sistem', '2026-02-10 04:11:26'),
(65, 21, 'LOGIN - Masuk ke sistem', '2026-02-10 04:11:29'),
(66, 21, 'LOGOUT - Keluar dari sistem', '2026-02-10 04:11:33'),
(67, 3, 'LOGIN - Masuk ke sistem', '2026-02-10 04:14:15'),
(68, 3, 'LOGOUT - Keluar dari sistem', '2026-02-10 04:14:17'),
(69, 3, 'LOGIN - Masuk ke sistem', '2026-02-10 04:15:57'),
(70, 3, 'LOGOUT - Keluar dari sistem', '2026-02-10 04:16:01'),
(71, 12, 'LOGIN - Masuk ke sistem', '2026-02-10 04:16:25'),
(72, 3, 'LOGIN - Masuk ke sistem', '2026-02-12 03:02:22'),
(73, 3, 'LOGOUT - Keluar dari sistem', '2026-02-12 03:10:32'),
(74, 21, 'LOGIN - Masuk ke sistem', '2026-02-12 03:13:15'),
(75, 21, 'LOGOUT - Keluar dari sistem', '2026-02-12 03:13:22'),
(76, 12, 'LOGIN - Masuk ke sistem', '2026-02-12 03:13:25'),
(77, 12, 'LOGOUT - Keluar dari sistem', '2026-02-12 03:18:00'),
(78, 3, 'LOGIN - Masuk ke sistem', '2026-02-12 03:18:02'),
(79, 3, 'LOGOUT - Keluar dari sistem', '2026-02-12 03:18:34'),
(80, 21, 'LOGIN - Masuk ke sistem', '2026-02-12 03:18:36'),
(81, 21, 'LOGOUT - Keluar dari sistem', '2026-02-12 03:18:43'),
(82, 12, 'LOGIN - Masuk ke sistem', '2026-02-12 03:18:45'),
(83, 12, 'LOGOUT - Keluar dari sistem', '2026-02-12 03:53:36'),
(84, 3, 'LOGIN - Masuk ke sistem', '2026-02-12 03:53:38'),
(85, 3, 'LOGOUT - Keluar dari sistem', '2026-02-12 03:53:56'),
(86, 12, 'LOGIN - Masuk ke sistem', '2026-02-12 03:53:59'),
(87, 12, 'TAMBAH Transaksi - ID 43 - masuk', '2026-02-12 03:54:58'),
(88, 12, 'LOGOUT - Keluar dari sistem', '2026-02-12 03:55:00'),
(89, 12, 'LOGIN - Masuk ke sistem', '2026-02-12 03:55:03'),
(90, 12, 'LOGOUT - Keluar dari sistem', '2026-02-12 03:55:06'),
(91, 3, 'LOGIN - Masuk ke sistem', '2026-02-12 03:55:08'),
(92, 3, 'LOGOUT - Keluar dari sistem', '2026-02-12 03:55:26'),
(93, 12, 'LOGIN - Masuk ke sistem', '2026-02-12 03:55:28'),
(94, 12, 'HAPUS Transaksi - ID 26', '2026-02-12 03:55:57'),
(95, 12, 'HAPUS Transaksi - ID 25', '2026-02-12 03:56:09'),
(96, 12, 'HAPUS Transaksi - ID 23', '2026-02-12 03:56:12'),
(97, 12, 'LOGOUT - Keluar dari sistem', '2026-02-12 03:56:19'),
(98, 3, 'LOGIN - Masuk ke sistem', '2026-02-12 03:56:21'),
(99, 3, 'UBAH Area Parkir - sungai (0/54)', '2026-02-12 03:56:31'),
(100, 3, 'UBAH Area Parkir - pondok (0/23)', '2026-02-12 03:56:36'),
(101, 3, 'UBAH Area Parkir - lapangan sepak bola (0/54)', '2026-02-12 03:56:41'),
(102, 3, 'UBAH Area Parkir - lapangan basket (0/19)', '2026-02-12 03:56:46'),
(103, 3, 'UBAH Area Parkir - danau (0/76)', '2026-02-12 03:56:54'),
(104, 3, 'UBAH Area Parkir - brotherhood (0/30)', '2026-02-12 03:56:59'),
(105, 3, 'LOGOUT - Keluar dari sistem', '2026-02-12 03:57:04'),
(106, 12, 'LOGIN - Masuk ke sistem', '2026-02-12 03:57:06'),
(107, 12, 'TAMBAH Transaksi - ID 3 - masuk', '2026-02-12 03:57:36'),
(108, 12, 'UBAH Transaksi - ID 3 - keluar', '2026-02-12 03:57:44'),
(109, 12, 'HAPUS Transaksi - ID 27', '2026-02-12 04:04:50'),
(110, 12, 'LOGOUT - Keluar dari sistem', '2026-02-12 04:04:55'),
(111, 3, 'LOGIN - Masuk ke sistem', '2026-02-12 04:04:58'),
(112, 3, 'UBAH Area Parkir - sungai (0/54)', '2026-02-12 04:05:09'),
(113, 3, 'LOGOUT - Keluar dari sistem', '2026-02-12 04:05:14'),
(114, 12, 'LOGIN - Masuk ke sistem', '2026-02-12 04:05:16'),
(115, 12, 'TAMBAH Transaksi - ID 3 - masuk', '2026-02-12 04:05:45'),
(116, 12, 'UBAH Transaksi - ID 3 - keluar', '2026-02-12 04:05:52'),
(117, 12, 'HAPUS Transaksi - ID 28', '2026-02-12 04:06:05'),
(118, 12, 'LOGOUT - Keluar dari sistem', '2026-02-12 04:06:18'),
(119, 3, 'LOGIN - Masuk ke sistem', '2026-02-12 04:06:21'),
(120, 3, 'LOGOUT - Keluar dari sistem', '2026-02-12 04:07:55'),
(121, 12, 'LOGIN - Masuk ke sistem', '2026-02-12 04:07:58'),
(122, 12, 'TAMBAH Transaksi - ID 4 - masuk', '2026-02-12 04:10:04'),
(123, 12, 'UBAH Transaksi - ID 4 - keluar', '2026-02-12 04:10:12'),
(124, 12, 'LOGOUT - Keluar dari sistem', '2026-02-12 04:10:18'),
(125, 3, 'LOGIN - Masuk ke sistem', '2026-02-12 04:10:21'),
(126, 3, 'UBAH Area Parkir - brotherhood (0/30)', '2026-02-12 04:10:29'),
(127, 3, 'LOGOUT - Keluar dari sistem', '2026-02-12 04:16:11'),
(128, 12, 'LOGIN - Masuk ke sistem', '2026-02-12 04:16:17'),
(129, 12, 'TAMBAH Transaksi - ID 3 - masuk', '2026-02-12 04:20:29'),
(130, 12, 'UBAH Transaksi - ID 3 - keluar', '2026-02-12 04:20:36'),
(131, 12, 'LOGOUT - Keluar dari sistem', '2026-02-12 04:21:45'),
(132, 3, 'LOGIN - Masuk ke sistem', '2026-02-12 04:21:48'),
(133, 3, 'LOGOUT - Keluar dari sistem', '2026-02-12 04:23:27'),
(134, 21, 'LOGIN - Masuk ke sistem', '2026-02-12 04:23:30'),
(135, 21, 'LOGIN - Masuk ke sistem', '2026-02-12 04:59:04'),
(136, 21, 'LOGOUT - Keluar dari sistem', '2026-02-12 04:59:16'),
(137, 3, 'LOGIN - Masuk ke sistem', '2026-02-12 04:59:20'),
(138, 3, 'LOGOUT - Keluar dari sistem', '2026-02-12 05:00:15'),
(139, 3, 'LOGIN - Masuk ke sistem', '2026-02-12 05:00:18'),
(140, 3, 'LOGOUT - Keluar dari sistem', '2026-02-12 05:00:21'),
(141, 12, 'LOGIN - Masuk ke sistem', '2026-02-12 05:00:23'),
(142, 12, 'TAMBAH Transaksi - ID 5 - masuk', '2026-02-12 05:01:05'),
(143, 12, 'UBAH Transaksi - ID 5 - keluar', '2026-02-12 05:01:33'),
(144, 12, 'LOGOUT - Keluar dari sistem', '2026-02-12 05:01:50'),
(145, 21, 'LOGIN - Masuk ke sistem', '2026-02-12 05:01:53'),
(146, 21, 'LOGOUT - Keluar dari sistem', '2026-02-12 05:01:57'),
(147, 12, 'LOGIN - Masuk ke sistem', '2026-02-12 05:02:00'),
(148, 12, 'LOGOUT - Keluar dari sistem', '2026-02-12 05:02:33'),
(149, 21, 'LOGIN - Masuk ke sistem', '2026-02-12 05:02:36'),
(150, 21, 'LOGOUT - Keluar dari sistem', '2026-02-12 05:02:42'),
(151, 3, 'LOGIN - Masuk ke sistem', '2026-02-12 05:02:45'),
(152, 3, 'LOGOUT - Keluar dari sistem', '2026-02-12 05:02:47'),
(153, 12, 'LOGIN - Masuk ke sistem', '2026-02-12 05:02:50'),
(154, 12, 'UBAH Transaksi - ID 5 - keluar', '2026-02-12 05:03:16'),
(155, 12, 'LOGOUT - Keluar dari sistem', '2026-02-12 05:09:27'),
(156, 3, 'LOGIN - Masuk ke sistem', '2026-02-12 06:16:04'),
(157, 3, 'LOGOUT - Keluar dari sistem', '2026-02-12 06:16:20'),
(158, 12, 'LOGIN - Masuk ke sistem', '2026-02-12 06:16:24'),
(159, 12, 'LOGOUT - Keluar dari sistem', '2026-02-12 06:16:27'),
(160, 21, 'LOGIN - Masuk ke sistem', '2026-02-12 06:16:30'),
(161, 21, 'LOGOUT - Keluar dari sistem', '2026-02-12 06:16:46'),
(162, 12, 'LOGIN - Masuk ke sistem', '2026-02-12 06:16:49'),
(163, 12, 'LOGOUT - Keluar dari sistem', '2026-02-12 06:17:01'),
(164, 21, 'LOGIN - Masuk ke sistem', '2026-02-12 06:17:16'),
(165, 21, 'LOGOUT - Keluar dari sistem', '2026-02-12 06:17:46'),
(166, 3, 'LOGIN - Masuk ke sistem', '2026-02-12 06:36:11'),
(167, 3, 'LOGOUT - Keluar dari sistem', '2026-02-12 06:42:53'),
(168, 3, 'LOGIN - Masuk ke sistem', '2026-02-12 06:42:55'),
(169, 3, 'LOGOUT - Keluar dari sistem', '2026-02-12 06:42:58'),
(170, 12, 'LOGIN - Masuk ke sistem', '2026-02-12 06:43:00'),
(171, 12, 'LOGOUT - Keluar dari sistem', '2026-02-12 06:43:02'),
(172, 21, 'LOGIN - Masuk ke sistem', '2026-02-12 06:43:04'),
(173, 21, 'LOGOUT - Keluar dari sistem', '2026-02-12 06:43:39'),
(174, 3, 'LOGIN - Masuk ke sistem', '2026-02-12 07:04:04'),
(175, 3, 'TAMBAH Tarif - mobil - Rp 20000', '2026-02-12 07:04:11'),
(176, 3, 'UBAH Tarif - mobil - Rp 25000', '2026-02-12 07:04:16'),
(177, 3, 'HAPUS Tarif - ID 24', '2026-02-12 07:04:20'),
(178, 3, 'LOGOUT - Keluar dari sistem', '2026-02-12 07:04:34'),
(179, 21, 'LOGIN - Masuk ke sistem', '2026-02-12 07:04:37'),
(180, 21, 'LOGOUT - Keluar dari sistem', '2026-02-12 07:04:54'),
(181, 12, 'LOGIN - Masuk ke sistem', '2026-02-12 07:04:57'),
(182, 12, 'LOGOUT - Keluar dari sistem', '2026-02-12 07:05:40'),
(183, 21, 'LOGIN - Masuk ke sistem', '2026-02-27 02:06:34'),
(184, 21, 'LOGOUT - Keluar dari sistem', '2026-02-27 02:06:56'),
(185, 12, 'LOGIN - Masuk ke sistem', '2026-02-27 02:07:24'),
(186, 21, 'LOGIN - Masuk ke sistem', '2026-02-27 03:42:33'),
(187, 21, 'LOGIN - Masuk ke sistem', '2026-02-27 03:59:37'),
(188, 21, 'LOGOUT - Keluar dari sistem', '2026-02-27 03:59:57'),
(189, 12, 'LOGIN - Masuk ke sistem', '2026-02-27 04:00:10'),
(190, 12, 'LOGOUT - Keluar dari sistem', '2026-02-27 04:00:29');

-- --------------------------------------------------------

--
-- Table structure for table `tb_tarif`
--

CREATE TABLE `tb_tarif` (
  `id_tarif` int(11) NOT NULL,
  `jenis_kendaraan` enum('motor','mobil','truk','lainnya') NOT NULL,
  `tarif_per_jam` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_tarif`
--

INSERT INTO `tb_tarif` (`id_tarif`, `jenis_kendaraan`, `tarif_per_jam`) VALUES
(20, 'mobil', 15000),
(22, 'motor', 5000),
(23, 'lainnya', 20000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_transaksi`
--

CREATE TABLE `tb_transaksi` (
  `id_parkir` int(11) NOT NULL,
  `id_kendaraan` int(11) NOT NULL,
  `waktu_masuk` datetime NOT NULL,
  `waktu_keluar` datetime NOT NULL,
  `id_tarif` int(11) NOT NULL,
  `durasi_jam` int(5) NOT NULL,
  `biaya_total` decimal(10,0) NOT NULL,
  `status` enum('masuk','keluar','','') NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_area` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_transaksi`
--

INSERT INTO `tb_transaksi` (`id_parkir`, `id_kendaraan`, `waktu_masuk`, `waktu_keluar`, `id_tarif`, `durasi_jam`, `biaya_total`, `status`, `id_user`, `id_area`) VALUES
(29, 4, '2026-02-12 12:00:00', '2026-02-12 14:00:00', 22, 2, 10000, 'keluar', 3, 1),
(30, 3, '2026-02-12 12:00:00', '2026-02-12 13:00:00', 20, 1, 15000, 'keluar', 3, 21),
(31, 5, '2026-02-13 12:00:00', '2026-02-13 14:00:00', 20, 4, 60000, 'keluar', 3, 21);

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(11) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` enum('admin','petugas','owner') NOT NULL,
  `status_aktif` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `nama_lengkap`, `username`, `password`, `role`, `status_aktif`) VALUES
(3, 'bayu efendi', 'efendi', 'b53fe7751b37e40ff34d012c7774d65f', 'admin', 1),
(12, 'rangga adi afrizal', 'rangga', 'e00cf25ad42683b3df678c61f42c6bda', 'petugas', 1),
(21, 'david atharaffi marcelleno', 'Marcelleno', '4ef5ba0c918c537fadba2ada54e3dd68', 'owner', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_area_parkir`
--
ALTER TABLE `tb_area_parkir`
  ADD PRIMARY KEY (`id_area`),
  ADD KEY `id_area` (`id_area`);

--
-- Indexes for table `tb_kendaraan`
--
ALTER TABLE `tb_kendaraan`
  ADD PRIMARY KEY (`Id_kendaraaan`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `tb_log_aktivitas`
--
ALTER TABLE `tb_log_aktivitas`
  ADD UNIQUE KEY `id_log_2` (`id_log`),
  ADD KEY `id_log` (`id_log`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `tb_tarif`
--
ALTER TABLE `tb_tarif`
  ADD PRIMARY KEY (`id_tarif`),
  ADD KEY `id_tarif` (`id_tarif`);

--
-- Indexes for table `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
  ADD PRIMARY KEY (`id_parkir`),
  ADD KEY `id_parkir` (`id_parkir`),
  ADD KEY `id_kendaraan` (`id_kendaraan`),
  ADD KEY `id_tarif` (`id_tarif`),
  ADD KEY `id_area` (`id_area`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `id_user` (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_area_parkir`
--
ALTER TABLE `tb_area_parkir`
  MODIFY `id_area` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tb_kendaraan`
--
ALTER TABLE `tb_kendaraan`
  MODIFY `Id_kendaraaan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `tb_log_aktivitas`
--
ALTER TABLE `tb_log_aktivitas`
  MODIFY `id_log` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=191;

--
-- AUTO_INCREMENT for table `tb_tarif`
--
ALTER TABLE `tb_tarif`
  MODIFY `id_tarif` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
  MODIFY `id_parkir` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=434;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_log_aktivitas`
--
ALTER TABLE `tb_log_aktivitas`
  ADD CONSTRAINT `tb_log_aktivitas_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `tb_user` (`id_user`);

--
-- Constraints for table `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
  ADD CONSTRAINT `tb_transaksi_ibfk_1` FOREIGN KEY (`id_kendaraan`) REFERENCES `tb_kendaraan` (`Id_kendaraaan`),
  ADD CONSTRAINT `tb_transaksi_ibfk_2` FOREIGN KEY (`id_tarif`) REFERENCES `tb_tarif` (`id_tarif`),
  ADD CONSTRAINT `tb_transaksi_ibfk_3` FOREIGN KEY (`id_area`) REFERENCES `tb_area_parkir` (`id_area`),
  ADD CONSTRAINT `tb_transaksi_ibfk_4` FOREIGN KEY (`id_user`) REFERENCES `tb_user` (`id_user`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
