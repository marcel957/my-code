<?php
include '../koneksi.php';

$id   = $_GET['id'];
$data = mysqli_query($mysql, "SELECT s.*, b.judul_buku FROM stok_buku s JOIN buku b ON s.id_buku=b.id_buku WHERE s.id_buku='$id'");
$row  = mysqli_fetch_assoc($data);

if (isset($_POST['simpan'])) {
    $total    = $_POST['jumlah_total'];
    $tersedia = $_POST['jumlah_tersedia'];
    $rak      = $_POST['letak_rak'];
    mysqli_query($mysql, "UPDATE stok_buku SET jumlah_total='$total', jumlah_tersedia='$tersedia', letak_rak='$rak' WHERE id_buku='$id'");
    echo "<script>alert('Stok Buku diupdate!'); window.location.href='stok.php';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Stok Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Edit Stok Buku</h1>
            <p class="text-muted mb-0">Perbarui informasi stok dan letak rak buku.</p>
        </div>
        <a href="stok.php" class="btn btn-outline-secondary">Kembali</a>
    </div>
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm border-0">
                <div class="card-body p-4">
                    <div class="mb-4">
                        <label class="form-label">Buku</label>
                        <input type="text" class="form-control" value="<?= $row['judul_buku'] ?> (ID: <?= $row['id_buku'] ?>)" disabled>
                    </div>
                    <form method="POST">
                        <div class="mb-3">
                            <label for="jumlah_total" class="form-label">Jumlah Total</label>
                            <input type="number" class="form-control" id="jumlah_total" name="jumlah_total" value="<?= $row['jumlah_total'] ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="jumlah_tersedia" class="form-label">Jumlah Tersedia</label>
                            <input type="number" class="form-control" id="jumlah_tersedia" name="jumlah_tersedia" value="<?= $row['jumlah_tersedia'] ?>" required>
                        </div>
                        <div class="mb-4">
                            <label for="letak_rak" class="form-label">Letak Rak</label>
                            <input type="text" class="form-control" id="letak_rak" name="letak_rak" value="<?= $row['letak_rak'] ?>" required>
                        </div>
                        <div class="d-flex gap-2">
                            <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
                            <a href="stok.php" class="btn btn-outline-secondary">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>