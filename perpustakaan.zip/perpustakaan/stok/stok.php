<?php
include '../koneksi.php';

$pesan = '';
$tipe_pesan = 'success';

if (isset($_POST['tambah'])) {
    $id_buku  = $_POST['id_buku'];
    $total    = $_POST['jumlah_total'];
    $tersedia = $_POST['jumlah_tersedia'];
    $rak      = $_POST['letak_rak'];
    $cek = mysqli_query($mysql, "SELECT * FROM stok_buku WHERE id_buku='$id_buku'");
    if (mysqli_num_rows($cek) > 0) {
        $pesan = "Stok untuk buku ini sudah ada! Silakan gunakan fitur edit.";
        $tipe_pesan = 'warning';
    } else {
        mysqli_query($mysql, "INSERT INTO stok_buku (id_buku, jumlah_total, jumlah_tersedia, letak_rak) VALUES ('$id_buku','$total','$tersedia','$rak')");
        $pesan = "Stok Buku ditambah!";
        $tipe_pesan = 'success';
    }
}

if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($mysql, "DELETE FROM stok_buku WHERE id_buku='$id'");
    $pesan = "Stok Buku dihapus!";
    $tipe_pesan = 'danger';
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Stok Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Data Stok Buku</h1>
            <p class="text-muted mb-0">Kelola stok buku perpustakaan.</p>
        </div>
        <a href="../index.php" class="btn btn-outline-secondary">Kembali</a>
    </div>
    <?php if ($pesan != '') { ?>
        <div class="alert alert-<?php echo $tipe_pesan; ?> alert-dismissible fade show" role="alert">
            <?php echo $pesan; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php } ?>
    <div class="card shadow-sm mb-4">
        <div class="card-header">
            <h2 class="h5 mb-0">Tambah Stok Buku</h2>
        </div>
        <div class="card-body">
            <form method="POST">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="id_buku" class="form-label">Buku</label>
                        <select class="form-select" id="id_buku" name="id_buku" required>
                            <?php
                            $buku = mysqli_query($mysql, "SELECT * FROM buku");
                            while ($row = mysqli_fetch_assoc($buku)) {
                                echo "<option value='{$row['id_buku']}'>{$row['judul_buku']} ({$row['id_buku']})</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="jumlah_total" class="form-label">Jumlah Total</label>
                        <input type="number" class="form-control" id="jumlah_total" name="jumlah_total" required>
                    </div>
                    <div class="col-md-6">
                        <label for="jumlah_tersedia" class="form-label">Jumlah Tersedia</label>
                        <input type="number" class="form-control" id="jumlah_tersedia" name="jumlah_tersedia" required>
                    </div>
                    <div class="col-md-6">
                        <label for="letak_rak" class="form-label">Letak Rak</label>
                        <input type="text" class="form-control" id="letak_rak" name="letak_rak" required>
                    </div>
                    <div class="col-12">
                        <button type="submit" name="tambah" class="btn btn-primary">Tambah Stok</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="card shadow-sm">
        <div class="card-header">
            <h2 class="h5 mb-0">Daftar Stok Buku</h2>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>ID Buku</th>
                            <th>Judul Buku</th>
                            <th>Jumlah Total</th>
                            <th>Jumlah Tersedia</th>
                            <th>Letak Rak</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $data = mysqli_query($mysql, "
                            SELECT s.*, b.judul_buku
                            FROM stok_buku s
                            JOIN buku b ON s.id_buku = b.id_buku
                        ");
                        while ($row = mysqli_fetch_assoc($data)) {
                            echo "<tr>
                                <td>{$row['id_buku']}</td>
                                <td>{$row['judul_buku']}</td>
                                <td>{$row['jumlah_total']}</td>
                                <td>{$row['jumlah_tersedia']}</td>
                                <td>{$row['letak_rak']}</td>
                                <td>
                                    <div class='d-flex gap-2'>
                                        <a href='edit_stok.php?id={$row['id_buku']}' class='btn btn-sm btn-warning'>Edit</a>
                                        <a href='stok.php?hapus={$row['id_buku']}' class='btn btn-sm btn-danger'>Hapus</a>
                                    </div>
                                </td>
                            </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>