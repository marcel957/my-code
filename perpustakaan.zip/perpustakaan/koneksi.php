<?php
$databaseHost = 'localhost';
$databaseName = 'perpustakaan';
$databaseUsername = 'root';
$databasePassword = '';

$mysql = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);
if($mysql == TRUE){
}else{
    echo "gagal terhubung";
}
?>         