<?php
include '../koneksi.php';

$id   = $_GET['id'];
$data = mysqli_query($mysql, "SELECT * FROM buku WHERE id_buku='$id'");
$row    = mysqli_fetch_assoc($data);

if (isset($_POST['simpan'])) {
    $judul    = $_POST['judul_buku'];
    $pengarang= $_POST['pengarang'];
    $penerbit = $_POST['penerbit'];
    $tahun    = $_POST['tahun_terbit'];
    mysqli_query($mysql, "UPDATE buku SET judul_buku='$judul', pengarang='$pengarang', penerbit='$penerbit', tahun_terbit='$tahun' WHERE id_buku='$id'");
    echo "<script>alert('Buku diupdate!'); window.location.href='buku.php';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Edit Buku</h1>
            <p class="text-muted mb-0">Perbarui data buku perpustakaan.</p>
        </div>
        <a href="buku.php" class="btn btn-outline-secondary">Kembali</a>
    </div>
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm border-0">
                <div class="card-body p-4">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">ID Buku</label>
                            <input type="text" class="form-control" value="<?= $row['id_buku'] ?>" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="judul_buku" class="form-label">Judul</label>
                            <input type="text" class="form-control" id="judul_buku" name="judul_buku" value="<?= $row['judul_buku'] ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="pengarang" class="form-label">Pengarang</label>
                            <input type="text" class="form-control" id="pengarang" name="pengarang" value="<?= $row['pengarang'] ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="penerbit" class="form-label">Penerbit</label>
                            <input type="text" class="form-control" id="penerbit" name="penerbit" value="<?= $row['penerbit'] ?>" required>
                        </div>
                        <div class="mb-4">
                            <label for="tahun_terbit" class="form-label">Tahun Terbit</label>
                            <input type="text" class="form-control" id="tahun_terbit" name="tahun_terbit" value="<?= $row['tahun_terbit'] ?>" required>
                        </div>
                        <div class="d-flex gap-2">
                            <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
                            <a href="buku.php" class="btn btn-outline-secondary">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>