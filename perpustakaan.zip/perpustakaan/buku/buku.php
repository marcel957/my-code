<?php
include '../koneksi.php';

$pesan = '';
$tipe_pesan = 'success';

if (isset($_POST['tambah'])) {
    $id       = $_POST['id_buku'];
    $judul    = $_POST['judul_buku'];
    $pengarang= $_POST['pengarang'];
    $penerbit = $_POST['penerbit'];
    $tahun    = $_POST['tahun_terbit'];
    mysqli_query($mysql, "INSERT INTO buku VALUES ('$id','$judul','$pengarang','$penerbit','$tahun')");
    $pesan = "Buku ditambah!";
    $tipe_pesan = 'success';
}

if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($mysql, "DELETE FROM buku WHERE id_buku='$id'");
    $pesan = "Buku dihapus!";
    $tipe_pesan = 'danger';
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Data Buku</h1>
            <p class="text-muted mb-0">Kelola data buku perpustakaan.</p>
        </div>
        <a href="../index.php" class="btn btn-outline-secondary">Kembali</a>
    </div>
    <?php if ($pesan != '') { ?>
        <div class="alert alert-<?php echo $tipe_pesan; ?> alert-dismissible fade show" role="alert">
            <?php echo $pesan; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php } ?>
    <div class="card shadow-sm mb-4">
        <div class="card-header">
            <h2 class="h5 mb-0">Tambah Buku</h2>
        </div>
        <div class="card-body">
            <form method="POST">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="id_buku" class="form-label">ID Buku</label>
                        <input type="text" class="form-control" id="id_buku" name="id_buku" required>
                    </div>
                    <div class="col-md-6">
                        <label for="judul_buku" class="form-label">Judul</label>
                        <input type="text" class="form-control" id="judul_buku" name="judul_buku" required>
                    </div>
                    <div class="col-md-6">
                        <label for="pengarang" class="form-label">Pengarang</label>
                        <input type="text" class="form-control" id="pengarang" name="pengarang" required>
                    </div>
                    <div class="col-md-6">
                        <label for="penerbit" class="form-label">Penerbit</label>
                        <input type="text" class="form-control" id="penerbit" name="penerbit" required>
                    </div>
                    <div class="col-md-6">
                        <label for="tahun_terbit" class="form-label">Tahun Terbit</label>
                        <input type="text" class="form-control" id="tahun_terbit" name="tahun_terbit" required>
                    </div>
                    <div class="col-12">
                        <button type="submit" name="tambah" class="btn btn-primary">Tambah</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="card shadow-sm">
        <div class="card-header">
            <h2 class="h5 mb-0">Daftar Buku</h2>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Judul</th>
                            <th>Pengarang</th>
                            <th>Penerbit</th>
                            <th>Tahun</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $data = mysqli_query($mysql, "SELECT * FROM buku");
                        while ($row = mysqli_fetch_assoc($data)) {
                            echo "<tr>
                                <td>{$row['id_buku']}</td>
                                <td>{$row['judul_buku']}</td>
                                <td>{$row['pengarang']}</td>
                                <td>{$row['penerbit']}</td>
                                <td>{$row['tahun_terbit']}</td>
                                <td>
                                    <div class='d-flex gap-2'>
                                        <a href='edit_buku.php?id={$row['id_buku']}' class='btn btn-sm btn-warning'>Edit</a>
                                        <a href='buku.php?hapus={$row['id_buku']}' class='btn btn-sm btn-danger'>Hapus</a>
                                    </div>
                                </td>
                            </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>