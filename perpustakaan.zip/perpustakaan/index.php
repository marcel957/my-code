<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">perpustakaan</h1>
            <p class="text-muted mb-0">Selamat datang di aplikasi perpustakaan!</p>
        </div>
        <a href="login.php?logout" class="btn btn-outline-secondary">Logout</a>
    </div>
        <div class="row g-4">
            <div class="col-md-6 col-xl-4">
                <div class="card h-100 shadow-sm border-0">
                    <div class="card-body d-flex flex-column">
                        <h2 class="h5">Data Anggota</h2>
                        <p class="text-muted flex-grow-1 mb-3">Kelola data anggota perpustakaan.</p>
                        <a href="anggota/anggota.php" class="btn btn-primary">Buka Menu</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-4">
                <div class="card h-100 shadow-sm border-0">
                    <div class="card-body d-flex flex-column">
                        <h2 class="h5">Data Buku</h2>
                        <p class="text-muted flex-grow-1 mb-3">Kelola daftar buku yang tersedia.</p>
                        <a href="buku/buku.php" class="btn btn-success">Buka Menu</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-4">
                <div class="card h-100 shadow-sm border-0">
                    <div class="card-body d-flex flex-column">
                        <h2 class="h5">Data Stok Buku</h2>
                        <p class="text-muted flex-grow-1 mb-3">Pantau dan atur jumlah stok buku.</p>
                        <a href="stok/stok.php" class="btn btn-warning text-dark">Buka Menu</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-6">
                <div class="card h-100 shadow-sm border-0">
                    <div class="card-body d-flex flex-column">
                        <h2 class="h5">Data Peminjaman</h2>
                        <p class="text-muted flex-grow-1 mb-3">Kelola transaksi peminjaman buku.</p>
                        <a href="peminjam/peminjaman.php" class="btn btn-info text-dark">Buka Menu</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-6">
                <div class="card h-100 shadow-sm border-0">
                    <div class="card-body d-flex flex-column">
                        <h2 class="h5">Laporan</h2>
                        <p class="text-muted flex-grow-1 mb-3">Lihat dan export laporan transaksi perpustakaan.</p>
                        <a href="laporan.php" class="btn btn-secondary">Buka Menu</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php
session_start();

if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

?>