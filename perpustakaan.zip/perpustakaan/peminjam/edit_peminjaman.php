<?php
include '../koneksi.php';

$id   = $_GET['id'];
$data = mysqli_query($mysql, "SELECT t.*, a.nama_anggota, b.judul_buku FROM transaksi_peminjaman t LEFT JOIN anggota a ON t.id_anggota=a.id_anggota LEFT JOIN buku b ON t.id_buku=b.id_buku WHERE t.id_pinjam='$id'");
$r    = mysqli_fetch_assoc($data);

if (isset($_POST['simpan'])) {
    $tgl_kembali = $_POST['tanggal_kembali'];
    $jatuh_tempo = $r['tanggal_jatuh_tempo'];
    $denda = 0;
    if ($tgl_kembali > $jatuh_tempo) {
        $selisih = (strtotime($tgl_kembali) - strtotime($jatuh_tempo)) / 86400;
        $denda   = $selisih * 1000;
    }
    mysqli_query($mysql, "UPDATE transaksi_peminjaman SET tanggal_kembali='$tgl_kembali', status='Kembali', denda='$denda' WHERE id_pinjam='$id'");
    mysqli_query($mysql, "UPDATE stok_buku SET jumlah_tersedia = jumlah_tersedia + 1 WHERE id_buku='{$r['id_buku']}'");
    echo "<script>alert('Buku dikembalikan! Denda: Rp $denda'); window.location.href='peminjaman.php';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head><title>Kembalikan Buku</title></head>
<body>

<h1>Kembalikan Buku</h1>
<a href="peminjaman.php">Kembali</a>
<hr>

<p>ID Pinjam   : <?= $r['id_pinjam'] ?></p>
<p>Anggota     : <?= $r['nama_anggota'] ?></p>
<p>Buku        : <?= $r['judul_buku'] ?></p>
<p>Tgl Pinjam  : <?= $r['tanggal_pinjam'] ?></p>
<p>Jatuh Tempo : <?= $r['tanggal_jatuh_tempo'] ?></p>
<p>Status      : <?= $r['status'] ?></p>
<hr>

<h2>Proses Pengembalian</h2>
<form method="POST">
    Tanggal Kembali : <input type="date" name="tanggal_kembali" required> <br>
    <small>* Denda: Rp 1.000 / hari kalau terlambat</small> <br><br>
    <input type="submit" name="simpan" value="Kembalikan Buku">
</form>
</body>
</html>