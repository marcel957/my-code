<?php
include '../koneksi.php';

if (isset($_POST['tambah'])) {
    $id_pinjam  = $_POST['id_pinjam'];
    $id_anggota = $_POST['id_anggota'];
    $id_buku    = $_POST['id_buku'];
    $tgl_pinjam = $_POST['tanggal_pinjam'];
    $jatuh_tempo= $_POST['tanggal_jatuh_tempo'];
    mysqli_query($mysql, "INSERT INTO transaksi_peminjaman (id_pinjam, id_anggota, id_buku, tanggal_pinjam, tanggal_jatuh_tempo) VALUES ('$id_pinjam','$id_anggota','$id_buku','$tgl_pinjam','$jatuh_tempo')");
    mysqli_query($mysql, "UPDATE stok_buku SET jumlah_tersedia = jumlah_tersedia - 1 WHERE id_buku='$id_buku'");
    echo "<div class='container py-4'><div class='alert alert-success' role='alert'>Peminjaman dicatat!</div></div>";
}

if (isset($_GET['hapus'])) {
    mysqli_query($mysql, "DELETE FROM transaksi_peminjaman WHERE id_pinjam='{$_GET['hapus']}'");
    echo "<div class='container py-4'><div class='alert alert-warning' role='alert'>Peminjaman dihapus!</div></div>";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Peminjaman</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
            <div>
                <h1 class="h3 mb-1">Data Peminjaman</h1>
                <p class="text-muted mb-0">Kelola data transaksi peminjaman buku perpustakaan.</p>
            </div>
            <a href="../index.php" class="btn btn-outline-secondary">Kembali</a>
        </div>
        <div class="card shadow-sm mb-4">
            <div class="card-header">
                <h2 class="h5 mb-0">Tambah Peminjaman</h2>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="id_pinjam" class="form-label">ID Pinjam</label>
                            <input type="text" name="id_pinjam" id="id_pinjam" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label for="id_anggota" class="form-label">Anggota</label>
                            <select name="id_anggota" id="id_anggota" class="form-select" required>
                                <?php
                                $anggota = mysqli_query($mysql, "SELECT * FROM anggota");
                                while ($row = mysqli_fetch_assoc($anggota)) {
                                    echo "<option value='{$row['id_anggota']}'>{$row['nama_anggota']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="id_buku" class="form-label">Buku</label>
                            <select name="id_buku" id="id_buku" class="form-select" required>
                                <?php
                                $buku = mysqli_query($mysql, "SELECT * FROM buku");
                                while ($row = mysqli_fetch_assoc($buku)) {
                                    echo "<option value='{$row['id_buku']}'>{$row['judul_buku']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="tanggal_pinjam" class="form-label">Tgl Pinjam</label>
                            <input type="date" name="tanggal_pinjam" id="tanggal_pinjam" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label for="tanggal_jatuh_tempo" class="form-label">Tgl Jatuh Tempo</label>
                            <input type="date" name="tanggal_jatuh_tempo" id="tanggal_jatuh_tempo" class="form-control" required>
                        </div>
                        <div class="col-12">
                            <button type="submit" name="tambah" class="btn btn-primary">Pinjam</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="card shadow-sm">
            <div class="card-header">
                <h2 class="h5 mb-0">Daftar Peminjaman</h2>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Anggota</th>
                                <th>Buku</th>
                                <th>Tgl Pinjam</th>
                                <th>Jatuh Tempo</th>
                                <th>Tgl Kembali</th>
                                <th>Denda</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $data = mysqli_query($mysql, "
                                SELECT t.*, a.nama_anggota, b.judul_buku
                                FROM transaksi_peminjaman t
                                LEFT JOIN anggota a ON t.id_anggota = a.id_anggota
                                LEFT JOIN buku b ON t.id_buku = b.id_buku
                            ");
                            while ($row = mysqli_fetch_assoc($data)) {
                                $kembali = $row['tanggal_kembali'] ? $row['tanggal_kembali'] : "-";
                                echo "<tr>
                                    <td>{$row['id_pinjam']}</td>
                                    <td>{$row['nama_anggota']}</td>
                                    <td>{$row['judul_buku']}</td>
                                    <td>{$row['tanggal_pinjam']}</td>
                                    <td>{$row['tanggal_jatuh_tempo']}</td>
                                    <td>$kembali</td>
                                    <td>{$row['denda']}</td>
                                    <td>{$row['status']}</td>
                                    <td>
                                        <a href='edit_peminjaman.php?id={$row['id_pinjam']}' class='btn btn-sm btn-warning'>Kembalikan</a>
                                        <a href='peminjaman.php?hapus={$row['id_pinjam']}' class='btn btn-sm btn-danger'>Hapus</a>
                                    </td>
                                </tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>