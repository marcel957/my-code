<?php
include '../koneksi.php';

$pesan = '';
$tipe_pesan = 'success';

if (isset($_POST['tambah'])) {
    $id    = $_POST['id_anggota'];
    $nama  = $_POST['nama_anggota'];
    $kelas = $_POST['kelas'];
    $email = $_POST['email'];
    mysqli_query($mysql, "INSERT INTO anggota VALUES ('$id','$nama','$kelas','$email', curdate())");
    $pesan = "Anggota ditambah!";
    $tipe_pesan = 'success';
}

if (isset($_GET['hapus'])) {
    mysqli_query($mysql, "DELETE FROM anggota WHERE id_anggota = '{$_GET['hapus']}'");
    $pesan = "Anggota dihapus!";
    $tipe_pesan = 'danger';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Anggota</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Data Anggota</h1>
            <p class="text-muted mb-0">Kelola data anggota perpustakaan.</p>
        </div>
        <a href="../index.php" class="btn btn-outline-secondary">Kembali</a>
    </div>
    <?php if ($pesan != '') { ?>
        <div class="alert alert-<?php echo $tipe_pesan; ?> alert-dismissible fade show" role="alert">
            <?php echo $pesan; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php } ?>
    <div class="card shadow-sm mb-4">
        <div class="card-header">
            <h2 class="h5 mb-0">Tambah Anggota</h2>
        </div>
        <div class="card-body">
            <form method="POST">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="id_anggota" class="form-label">ID</label>
                        <input type="text" class="form-control" id="id_anggota" name="id_anggota" required>
                    </div>
                    <div class="col-md-6">
                        <label for="nama_anggota" class="form-label">Nama</label>
                        <input type="text" class="form-control" id="nama_anggota" name="nama_anggota" required>
                    </div>
                    <div class="col-md-6">
                        <label for="kelas" class="form-label">Kelas</label>
                        <input type="text" class="form-control" id="kelas" name="kelas" required>
                    </div>
                    <div class="col-md-6">
                        <label for="email" class="form-label">Email</label>
                        <input type="text" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="col-12">
                        <button type="submit" name="tambah" class="btn btn-primary">Tambah</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="card shadow-sm">
        <div class="card-header">
            <h2 class="h5 mb-0">Daftar Anggota</h2>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>Kelas</th>
                            <th>Email</th>
                            <th>Tgl Daftar</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $data = mysqli_query($mysql, "SELECT * FROM anggota");
                        while ($row = mysqli_fetch_assoc($data)) {
                            echo "<tr>
                                <td>{$row['id_anggota']}</td>
                                <td>{$row['nama_anggota']}</td>
                                <td>{$row['kelas']}</td>
                                <td>{$row['email']}</td>
                                <td>{$row['tanggal_daftar']}</td>
                                <td>
                                    <div class='d-flex gap-2'>
                                        <a href='edit_anggota.php?id={$row['id_anggota']}' class='btn btn-sm btn-warning'>Edit</a>
                                        <a href='anggota.php?hapus={$row['id_anggota']}' class='btn btn-sm btn-danger'>Hapus</a>
                                    </div>
                                </td>
                            </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>