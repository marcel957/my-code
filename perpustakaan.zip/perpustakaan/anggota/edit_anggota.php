<?php
include '../koneksi.php';

$id    = $_GET['id'];
$data  = mysqli_query($mysql, "SELECT * FROM anggota WHERE id_anggota='$id'");
$row     = mysqli_fetch_assoc($data);

if (isset($_POST['simpan'])) {
    $nama  = $_POST['nama_anggota'];
    $kelas = $_POST['kelas'];
    $email = $_POST['email'];
    mysqli_query($mysql, "UPDATE anggota SET nama_anggota='$nama', kelas='$kelas', email='$email' WHERE id_anggota='$id'");
    echo "<script>alert('Data diupdate!'); window.location.href='anggota.php';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Anggota</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Edit Anggota</h1>
            <p class="text-muted mb-0">Perbarui data anggota perpustakaan.</p>
        </div>
        <a href="anggota.php" class="btn btn-outline-secondary">Kembali</a>
    </div>
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm border-0">
                <div class="card-body p-4">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">ID Anggota</label>
                            <input type="text" class="form-control" value="<?= $row['id_anggota'] ?>" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="nama_anggota" class="form-label">Nama</label>
                            <input type="text" class="form-control" id="nama_anggota" name="nama_anggota" value="<?= $row['nama_anggota'] ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="kelas" class="form-label">Kelas</label>
                            <input type="text" class="form-control" id="kelas" name="kelas" value="<?= $row['kelas'] ?>" required>
                        </div>
                        <div class="mb-4">
                            <label for="email" class="form-label">Email</label>
                            <input type="text" class="form-control" id="email" name="email" value="<?= $row['email'] ?>" required>
                        </div>
                        <div class="d-flex gap-2">
                            <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
                            <a href="anggota.php" class="btn btn-outline-secondary">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>