<?php
session_start();
define('APP_USER', 'marcel');
define('APP_PASS', '12345');
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit;
}
if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true) {
    header('Location: index.php');
    exit;
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    if ($username === '' || $password === '') {
        $error = 'Username dan password harus diisi.';
    } elseif ($username === APP_USER && $password === APP_PASS) {
        $_SESSION['user_logged_in'] = true;
        $_SESSION['username'] = $username;
        header('Location: index.php');
        exit;
    } else {
        $error = 'Username atau password salah.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Aplikasi Kasir</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #ffffff 0%, #ffffff 100%);
        }
        .login-card {
            width: 100%;
            max-width: 400px;
            border: none;
        }
        .login-title {
            color: #4bc6c0;
        }
        .login-input {
            border-color: #52c3c7 !important;
        }
        .login-btn {
            background: linear-gradient(135deg, #65edd6 0%, #7ef6d0 100%);
            color: white;
            border: none;
        }
        .login-btn:hover {
            color: white;
        }
    </style>
</head>
<body class="d-flex justify-content-center align-items-center min-vh-100">
    <div class="card p-4 shadow-lg login-card">
        <div class="text-center mb-4">
            <h1 class="mb-2 login-title">perpustakaan</h1>
            <p class="text-muted">Silakan login untuk melanjutkan</p>
        </div>
        <form method="post" autocomplete="off">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control border-2 login-input" id="username" name="username"
                    value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                    placeholder="Username" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control border-2 login-input" id="password" name="password" 
                    placeholder="Password" required>
            </div>
            <button class="btn w-100 login-btn" type="submit">Login</button>
        </form>
        <?php if ($error): ?>
            <div class="alert alert-danger mt-3 mb-0"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <div class="text-center mt-3">
            <small class="text-muted">© 2026 perpustakaan</small>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
