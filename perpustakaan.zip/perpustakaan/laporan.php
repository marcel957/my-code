<?php
include 'koneksi.php';

$tanggal_awal = isset($_GET['tanggal_awal']) ? $_GET['tanggal_awal'] : '';
$tanggal_akhir = isset($_GET['tanggal_akhir']) ? $_GET['tanggal_akhir'] : '';
$sql = "SELECT t.*, a.nama_anggota, b.judul_buku
        FROM transaksi_peminjaman t
        LEFT JOIN anggota a ON t.id_anggota = a.id_anggota
        LEFT JOIN buku b ON t.id_buku = b.id_buku
        WHERE 1=1";
if ($tanggal_awal != '') {
    $sql .= " AND t.tanggal_pinjam >= '" . mysqli_real_escape_string($mysql, $tanggal_awal) . "'";
}
if ($tanggal_akhir != '') {
    $sql .= " AND t.tanggal_pinjam <= '" . mysqli_real_escape_string($mysql, $tanggal_akhir) . "'";
}
if (isset($_GET['export'])) {
    header("Content-Type: application/vnd-ms-excel");
    header("Content-Disposition: attachment; filename=laporan_transaksi.xls");
    $excel = mysqli_query($mysql, $sql);
    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>ID Pinjam</th>";
    echo "<th>Nama Anggota</th>";
    echo "<th>Judul Buku</th>";
    echo "<th>Tanggal Pinjam</th>";
    echo "<th>Tanggal Jatuh Tempo</th>";
    echo "<th>Tanggal Kembali</th>";
    echo "<th>Status</th>";
    echo "<th>Denda</th>";
    echo "</tr>";

    while ($row = mysqli_fetch_assoc($excel)) {
        echo "<tr>";
        echo "<td>" . $row['id_pinjam'] . "</td>";
        echo "<td>" . $row['nama_anggota'] . "</td>";
        echo "<td>" . $row['judul_buku'] . "</td>";
        echo "<td>" . $row['tanggal_pinjam'] . "</td>";
        echo "<td>" . $row['tanggal_jatuh_tempo'] . "</td>";
        echo "<td>" . $row['tanggal_kembali'] . "</td>";
        echo "<td>" . $row['status'] . "</td>";
        echo "<td>" . $row['denda'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    exit;
}

$data = mysqli_query($mysql, $sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
            <div>
                <h1 class="h3 mb-1">Laporan Transaksi</h1>
                <p class="text-muted mb-0">Filter dan export data transaksi peminjaman.</p>
            </div>
            <div class="d-flex gap-2">
                <a href="index.php" class="btn btn-outline-secondary">Kembali</a>
                <a href="laporan.php?export=1&tanggal_awal=<?php echo $tanggal_awal; ?>&tanggal_akhir=<?php echo $tanggal_akhir; ?>" class="btn btn-success">Export Excel</a>
            </div>
        </div>
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label for="tanggal_awal" class="form-label">Tanggal Awal</label>
                        <input type="date" name="tanggal_awal" id="tanggal_awal" class="form-control" value="<?php echo $tanggal_awal; ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="tanggal_akhir" class="form-label">Tanggal Akhir</label>
                        <input type="date" name="tanggal_akhir" id="tanggal_akhir" class="form-control" value="<?php echo $tanggal_akhir; ?>">
                    </div>
                    <div class="col-md-4">
                        <button type="submit" class="btn btn-primary">Tampilkan</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>ID Pinjam</th>
                                <th>Nama Anggota</th>
                                <th>Judul Buku</th>
                                <th>Tanggal Pinjam</th>
                                <th>Tanggal Jatuh Tempo</th>
                                <th>Tanggal Kembali</th>
                                <th>Status</th>
                                <th>Denda</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_assoc($data)) { ?>
                            <tr>
                                <td><?php echo $row['id_pinjam']; ?></td>
                                <td><?php echo $row['nama_anggota']; ?></td>
                                <td><?php echo $row['judul_buku']; ?></td>
                                <td><?php echo $row['tanggal_pinjam']; ?></td>
                                <td><?php echo $row['tanggal_jatuh_tempo']; ?></td>
                                <td><?php echo $row['tanggal_kembali']; ?></td>
                                <td><?php echo $row['status']; ?></td>
                                <td><?php echo $row['denda']; ?></td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>